import importlib

from .quadoa import *

# wildcard import above does not import "private" variables like __version__
# this makes them available
globals().update(importlib.import_module('quadoa.quadoa').__dict__)