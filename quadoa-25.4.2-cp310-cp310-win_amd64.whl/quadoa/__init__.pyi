"""Quadoa Optical CAD
-----------------------

"""
from __future__ import annotations
import quadoa.quadoa
import typing
import importlib

__all__ = [
    "DataObject1C",
    "DataObject1D",
    "DataObject2C",
    "DataObject2D",
    "DataObject3C",
    "DataObject3D",
    "DataObject4D",
    "IGES",
    "ImageObjectC",
    "ImageObjectD",
    "QuadoaCore",
    "S",
    "STEP",
    "STL",
    "W",
    "absOverExitPupil",
    "absOverImageSurf",
    "afocal",
    "afocalExitPupil",
    "after",
    "allFieldAllWave",
    "allFieldPrimaryWave",
    "apertureAnnular",
    "apertureArray",
    "apertureCirc",
    "apertureElliptic",
    "apertureHex",
    "apertureOr",
    "aperturePolygon",
    "apertureRect",
    "apertureType",
    "astigmatismW222",
    "attenuatorConst",
    "attenuatorCosine",
    "attenuatorGauss",
    "axialColor",
    "axisref",
    "before",
    "cadFileType",
    "circular",
    "coatingAngleAndWaveDependant",
    "coatingAngleDependant",
    "coatingArray",
    "coatingFullData",
    "coatingIdealAR",
    "coatingIdealMirror",
    "coatingPupilPosDependant",
    "coatingSimple",
    "coatingThinFilmStack",
    "coatingType",
    "coatingWavelengthDep",
    "comaW131",
    "distortionW311",
    "distributionFootprintType",
    "entrancePupil",
    "equal",
    "equalDensityRings",
    "error",
    "exitPupil",
    "extendedSource",
    "fanX",
    "fanXY",
    "fanY",
    "fieldAngle",
    "firstFieldAllWave",
    "firstFieldPrimaryWave",
    "floatFromStop",
    "focal",
    "formAcylinder",
    "formAcylinderQBfs",
    "formAcylinderQCon",
    "formAsphere",
    "formAsphereQBfs",
    "formAsphereQCon",
    "formAxicon",
    "formBiconic",
    "formCosine",
    "formCylinder",
    "formGaussPeak",
    "formGaussPeakElliptic",
    "formGaussPeakEllipticSuper",
    "formGaussPeakRectangularSuper",
    "formGaussPeakSuper",
    "formInterp",
    "formManipulationOperator",
    "formOffAxisAsphere",
    "formOperatorArray",
    "formOperatorFresnel",
    "formOperatorHexArray",
    "formParaboloid",
    "formPeriodicRotation",
    "formPlane",
    "formPython",
    "formSphere",
    "formTorus",
    "formType",
    "formXYZPoly",
    "formZernFringe",
    "formZernSymmetric",
    "fromSurface",
    "gaussian",
    "gaussianBeam",
    "gaussianElliptic",
    "ghostGenFieldWaveType",
    "ghostGenRayType",
    "ghostKeepType",
    "gridHexagonal",
    "gridOptimized",
    "gridQuadratic",
    "hubLike",
    "ideal",
    "imageHeight",
    "importMode",
    "jonesComplex",
    "jonesPhase",
    "keepAll",
    "lateralColor",
    "linear",
    "minimal",
    "noField",
    "none",
    "objectHeight",
    "objectSpaceNA",
    "obscurationCirc",
    "obscurationElliptic",
    "obscurationRect",
    "obscurationType",
    "onPlane",
    "onSphere",
    "ownChief",
    "paramBool",
    "paramDouble",
    "paramDummy",
    "paramError",
    "paramInt",
    "paramString",
    "paramType",
    "petzvalW220",
    "phaseAxial",
    "phaseGaussPeak",
    "phaseGaussPeakElliptic",
    "phaseGaussPeakEllipticSuper",
    "phaseGaussPeakRectangularSuper",
    "phaseGaussPeakSuper",
    "phaseGrating",
    "phaseInterp",
    "phaseManipulationOperator",
    "phaseOperatorArray",
    "phaseOperatorHexArray",
    "phasePython",
    "phaseRadial",
    "phaseSpiral",
    "phaseType",
    "phaseXYZPoly",
    "phaseZernFringe",
    "phaseZernSymmetric",
    "planeWF",
    "pointSource",
    "polarInteractionType",
    "polarReferenceCoo",
    "polarizationAngleDependantRetarder",
    "polarizationCircularPolarizer",
    "polarizationGeneralJones",
    "polarizationGeneralRetarder",
    "polarizationHalfWP",
    "polarizationLinearPolarizer",
    "polarizationMueller",
    "polarizationPupilPosAndWaveDepRetarder",
    "polarizationPupilPosDepRetarder",
    "polarizationQuarterWP",
    "polarizationType",
    "polarizationWaveAndAngDepRetarder",
    "polarizationWavelengthDependantRetarder",
    "positionAndAngle",
    "primaryChief",
    "projection",
    "quasiRandom",
    "random",
    "randomEqualDensity",
    "rayfile",
    "sameAsSequence",
    "seidelAberration",
    "seidelType",
    "sequenceApertureType",
    "sequenceApodizationType",
    "sequenceDistributionType",
    "sequenceFieldType",
    "sequenceImageSpaceType",
    "sequenceOPDChiefRefType",
    "sequenceOPDRefType",
    "sequencePolarizationType",
    "sequenceSourceType",
    "singleFreeDefRay",
    "singleRing",
    "sp",
    "sphericalW040",
    "stokes",
    "superGauss",
    "superGaussElliptic",
    "superGaussRectangular",
    "worstByMaxIrrad",
    "worstByTotalFlux"
]


class DataObject1C():
    """
    Array class that defines a 2dim, complex double array of shape ``1 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::

        import numpy as np
        arr: np.ndarray = myDataObject.getData()

    Additionally, the dataObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::

        import numpy as np
        arr: np.ndarray = np.array(myDataObject, copy=False)

    However, the ``shape`` and ``dtype`` of the returned array is ``1 x n x 2`` and
    ``float64``. Convert it to a real ``complex double`` array by::

        arr.dtype = complex  # convert to complex
        arr = np.squeeze(arr, axis=2)  # remove the last dimension
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
            n: create a DataObject of type ``complex double`` and shape ``1 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.complex128]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``complex128`` and the shape ``1 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 1)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 1)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class DataObject1D():
    """
    Array class that defines a 2dim, ``float64`` array of shape ``1 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::
        
        import numpy as np
        arr: np.ndarray = myDataObject.getData()
      
    Additionally, the dataObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::
        
        import numpy as np
        arr: np.ndarray = np.array(myDataObject, copy=False)
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
            n: create a DataObject of type ``double`` and shape ``1 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.float64]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``float64`` and the shape ``1 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 1)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 1)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class DataObject2C():
    """
    Array class that defines a 2dim, ``complex double`` array of shape ``2 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::

        import numpy as np
        arr: np.ndarray = myDataObject.getData()

    However, the ``shape`` and ``dtype`` of the returned array is ``2 x n x 2`` and
    ``float64``. Convert it to a real ``complex double`` array by::

        arr.dtype = complex  # convert to complex
        arr = np.squeeze(arr, axis=2)  # remove the last dimension
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
        n: create a DataObject of type ``complex double`` and shape ``2 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.complex128]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``complex128`` and the shape ``2 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 2)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 2)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class DataObject2D():
    """
    Array class that defines a 2dim, ``float64`` array of shape ``2 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::
        
        import numpy as np
        arr: np.ndarray = myDataObject.getData()
      
    Additionally, the dataObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::
        
        import numpy as np
        arr: np.ndarray = np.array(myDataObject, copy=False)
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
        n: create a DataObject of type ``double`` and shape ``2 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.float64]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``float64`` and the shape ``2 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 2)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 2)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class DataObject3C():
    """
    Array class that defines a 2dim, ``complex double`` array of shape ``3 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::

        import numpy as np
        arr: np.ndarray = myDataObject.getData()

    However, the ``shape`` and ``dtype`` of the returned array is ``3 x n x 2`` and
    ``float64``. Convert it to a real ``complex double`` array by::

        arr.dtype = complex  # convert to complex
        arr = np.squeeze(arr, axis=2)  # remove the last dimension
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
        n: create a DataObject of type ``complex double`` and shape ``3 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.complex128]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``complex128`` and the shape ``3 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 2)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 2)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class DataObject3D():
    """
    Array class that defines a 2dim, ``float64`` array of shape ``3 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::
        
        import numpy as np
        arr: np.ndarray = myDataObject.getData()
      
    Additionally, the dataObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::
        
        import numpy as np
        arr: np.ndarray = np.array(myDataObject, copy=False)
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
            n: create a DataObject of type ``double`` and shape ``3 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.float64]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``float64`` and the shape ``3 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 3)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 3)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class DataObject4D():
    """
    Array class that defines a 2dim, ``float64`` array of shape ``4 x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::
        
        import numpy as np
        arr: np.ndarray = myDataObject.getData()
      
    Additionally, the dataObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::
        
        import numpy as np
        arr: np.ndarray = np.array(myDataObject, copy=False)
    """
    def __init__(self, n: int = 0) -> None: 
        """
        Args:
        n: create a DataObject of type ``double`` and shape ``4 x n``
        """
    def getData(self) -> numpy.ndarray[numpy.float64]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``float64`` and the shape ``4 x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrCoordinates(self) -> int: 
        """
        Return the number of coordinates the poins in the array have (always: 4)
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows (always: 4)
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    pass
class ImageObjectC():
    """
    Array class that defines a 2dim, ``complex128`` array of shape ``m x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::

        import numpy as np
        arr: np.ndarray = myImageObject.getData()

    Additionally, the ImageObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::

        import numpy as np
        arr: np.ndarray = np.array(myImageObject, copy=False)
    """
    def __init__(self, rows: int = 0, cols: int = 0) -> None: 
        """
        Args:
        rows: number of rows for a newly created array
        cols: number of columns
        """
    def getData(self) -> numpy.ndarray[numpy.complex128]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``complex128`` and the shape ``m x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    def getXMax(self) -> float: 
        """
        Return the maximum X-coordinate of the data in the array
        """
    def getXMin(self) -> float: 
        """
        Return the minimum X-coordinate of the data in the array
        """
    def getYMax(self) -> float: 
        """
        Return the maximum Y-coordinate of the data in the array
        """
    def getYMin(self) -> float: 
        """
        Return the minimum Y-coordinate of the data in the array
        """
    pass
class ImageObjectD():
    """
    Array class that defines a 2dim, ``float64`` array of shape ``m x n``.

    The content of this array can be accessed via numpy arrays. There are two
    approaches. Directly access a view on the data as :py:class:`numpy.ndarray`
    via::
        
        import numpy as np
        arr: np.ndarray = myImageObject.getData()
      
    Additionally, the ImageObject exposes the Python buffer protocol, such that
    it can also be consumed by any object, that accepts another object with the
    buffer protocol. For instance it is also possible to get a numpy array via
    the following method (use ``copy=False`` to avoid a deep copy)::
        
        import numpy as np
        arr: np.ndarray = np.array(myImageObject, copy=False)
    """
    def __init__(self, rows: int = 0, cols: int = 0) -> None: 
        """
        Args:
        rows: number of rows for a newly created array
        cols: number of columns
        """
    def getData(self) -> numpy.ndarray[numpy.float64]: 
        """
        Returns a view on the array as :py:class:`numpy.ndarray`.

        The data type is ``float64`` and the shape ``m x n``.
        """
    def getNrColumns(self) -> int: 
        """
        Return the number of columns
        """
    def getNrPoints(self) -> int: 
        """
        Return the number of points
        """
    def getNrRows(self) -> int: 
        """
        Return the number of rows
        """
    def getNrValidPoints(self) -> int: 
        """
        Return the number of valid points
        """
    def getXMax(self) -> float: 
        """
        Return the maximum X-coordinate of the data in the array
        """
    def getXMin(self) -> float: 
        """
        Return the minimum X-coordinate of the data in the array
        """
    def getYMax(self) -> float: 
        """
        Return the maximum Y-coordinate of the data in the array
        """
    def getYMin(self) -> float: 
        """
        Return the minimum Y-coordinate of the data in the array
        """
    pass
class QuadoaCore():
    def __init__(self) -> None: ...
    def addApertureToSurface(self, row_nr: int, type: apertureType) -> bool: 
        """
        Adds an aperture to the surface specified by the row-nr. If the item at the row is not a surface
        the method returns false. The type of the aperture is specified by type.

        Args:
            row_nr: row index of the item in the tree
            type: type of the aperture object
        """
    def addCoatingToSurface(self, row_nr: int, type: coatingType) -> bool: 
        """
        Adds a coating element to the surface specified by the row-nr. If the item at the row is not a surface
        the method returns false. The type of the coating is specified by type.

        Args:
            row_nr: row index of the item in the tree
            type: type of the aperture object
        """
    def addFormToSurface(self, row_nr: int, type: formType) -> bool: 
        """
        Adds a form to the surface specified by the row-nr. If the item at the row is not a surface
        the method returns false. The type of the form is specified by type.

        Args:
            row_nr: row index of the item in the tree
            type: type of the aperture object
        """
    def addObscurationToSurface(self, row_nr: int, type: obscurationType) -> bool: 
        """
        Adds an obscuration to the surface specified by the row-nr. If the item at the row is not a surface
        the method returns false. The type of the obscuration is specified by type.

        Args:
            row_nr: row index of the item in the tree
            type: type of the aperture object
        """
    def addPhaseToSurface(self, row_nr: int, type: phaseType) -> bool: 
        """
        Adds a phase to the surface specified by the row-nr. If the item at the row is not a surface
        the method returns false. The type of the phase is specified by type.

        Args:
            row_nr: row index of the item in the tree
            type: type of the aperture object
        """
    def addPolarizationToSurface(self, row_nr: int, type: polarizationType) -> bool: 
        """
        Adds a polarization element to the surface specified by the row-nr. If the item at the row is not a surface
        the method returns false. The type of the polarization element is specified by type.

        Args:
            row_nr: row index of the item in the tree
            type: type of the aperture object
        """
    def applyChangesAndInitModel(self) -> bool: 
        """
        Needs to be called after new parameters have been set so the model gets actually updated

        If traceRays() is called this is not necessary since it will automaticall update before tracing
        """
    def clearAllLensCatalogs(self) -> None: 
        """
        Clears any lens catalogs that have been loaded by loadLensCatalogFile().
        """
    def clearAllMaterialCatalogs(self) -> None: 
        """
        Clears any materials that have been loaded by loadMaterialFile().
        """
    def clearErrorsAndWarnings(self) -> None: 
        """
        Clears any errors or warnings.
        """
    def exportCADSTL(self, filename: str, radial: int, angular: int) -> bool: 
        """
        Exports the currently loaded model as STL CAD file.

        Args:
            filename: the filename to be exported
            radial: count of radial segments for the meshing
            angular: count of radial segments for the meshing)

        Returns:
            true if success
        """
    def exportSequenceAsCodeV(self, filename: str, seq_nr: int) -> bool: 
        """
        Exports a sequence to a SEQ file.

        Args:
            filename: the filename to be exported
            seq_nr: index of the sequence to export

        Returns:
            true if success
        """
    def exportSequenceAsList(self, filename: str, seq_nr: int) -> bool: 
        """
        Exports a sequence in the model to a csv clear text file.

        The content will hold following information:

        Surf Nr, Comment, Radius, Thickness, Material

        Note that the file will not contain any data
        about decentered or tilted objects and only
        and no information about more complex surface forms or features.

        Args:
            filename: the filename to be exported (e.g. list.txt or list.csv)
            seq_nr: index of the sequence to export)

        Returns:
            true if success
        """
    def exportSequenceAsZMX(self, filename: str, seq_nr: int) -> bool: 
        """
        Exports a sequence to a ZMX file.
        Args:
            filename: the filename to be exported
            seq_nr: index of the sequence to export

        Returns:
            true if success
        """
    def generateDiffractiveGhostSequences(self, seq_nr: int, ghost_order: int, hide: bool, convert_stop: bool, gt: ghostGenRayType) -> bool: 
        """
        Generates diffractive ghost sequences out of a given sequence.
        If more than one diffractive elements are in the sequence
        any combination of diffraction orders will be generated.

        Args:
            seq_nr: index of the sequence
            ghost_order: diffraction order up to which to generate ghosts (e.g. 3 will generate ghosts up to +-3 order)
            hide: hide the sequence (when model is opened in gui)
            convert_stop: move the stopsurface to the first surface to ensure equal illumination
            gt: ghost ray generation type)
        """
    def generateGhostSequences(self, seq_nr: int, ghost_order: int, hide: bool, convert_stop: bool, gt: ghostGenRayType, f_w_type: ghostGenFieldWaveType, keep_type: ghostKeepType, n_keep: int) -> bool: 
        """
        Generates ghost sequences out of a given sequence.

        Args:
            seq_nr: index of the sequence
            ghost_order: 1 for single bounce, 2 for double bounce
            hide: hide the sequence (when model is opened in gui)
            convert_stop: move the stopsurface to the first surface to ensure equal illumination
            gt: ghost ray generation type
            f_w_type: ghost filed and wavelenght selection type
            keep_type: ghost pre-filter type
            n_keep: maximim number of ghost sequences to keep
        """
    def getActiveVariables(self, merit_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the values of all active variables

        Args:
            merit_nr: index of the merit function
        """
    def getAiryDiskDiameter(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the airy disk diameter for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getAmplitude(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the amplitude of the rays.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getApertureHullByRow(self, row_nr: int, aperture_nr: int, grid_size: int) -> DataObject2D: 
        """
        Returns a DataObject2D containing the (x, y) coordinate of the hull
        around a specific aperture in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            aperture_nr: index nr of the aperture
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getApertureHullBySequence(self, seq_nr: int, surf_nr: int, aperture_nr: int, grid_size: int) -> DataObject2D: 
        """
        Returns a DataObject2D containing the (x, y) coordinate of the hull
        around a specific aperture in the local surface coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
            aperture_nr: index nr of the aperture
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getApertureType(self, seq_nr: int) -> sequenceApertureType: 
        """
        Returns the type of the aperture definition for a sequence specified by seq_nr.

        The aperture type type can be changed by setApertureType()
        Args:
            seq_nr: index of the sequence
        """
    def getApertureValue(self, seq_nr: int) -> float: 
        """
        Returns the value set for the aperture of a sequence specified by seq_nr.
        Depending on the setting of the aperture type this value may be the NA, the aperture diameter.

        In case of a sequence with floating aperture, where the aperture is defined by the stop surface,
        the returned value has no meaning"

        If the aperture type is not a floating aperture the value can be changed by setApertureValue()

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationExponent(self, seq_nr: int) -> float: 
        """
        Returns the exponent of a super gaussian apodization for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationExponentX(self, seq_nr: int) -> float: 
        """
        Returns the exponent of an elliptic super gaussian apodization in X-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationExponentY(self, seq_nr: int) -> float: 
        """
        Returns the exponent of an elliptic super gaussian apodization in Y-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationSigma(self, seq_nr: int) -> float: 
        """
        Returns the standard deviation of a gaussian apodization for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationSigmaX(self, seq_nr: int) -> float: 
        """
        Returns the standard deviation of an elliptic gaussian apodization in X-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationSigmaY(self, seq_nr: int) -> float: 
        """
        Returns the standard deviation in of an elliptic gaussian apodization Y-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationTotalPower(self, seq_nr: int) -> float: 
        """
        Returns the total power of the apodization in W definition for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getApodizationType(self, seq_nr: int) -> sequenceApodizationType: 
        """
        Returns the type of the apodization definition for a sequence specified by seq_nr.

        The apodization type can be changed by setApodizationType()

        Args:
            seq_nr: index of the sequence
        """
    def getBeamletPropagationInterferogram(self, seq_nr_1: int, field_nr_1: int, wavelength_nr_1: int, conf_1: int, seq_nr_2: int, field_nr_2: int, wavelength_nr_2: int, conf_2: int, prop_start_surf_1: int, prop_start_surf_2: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the intensity of the interference of two sequences where the field is for each sequence is propagated via beamlet propagation.
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr_1: index of the first squence
            field_nr_1: index of the first field
            wavelength_nr_1: index of the first wavelength (needs to match)
            conf_1: configuration of multiconfig lookup table of the first sequence
            seq_nr_2: index of the second squence
            field_nr_2: index of the second field
            wavelength_nr_2: index of the second wavelength (needs to match)
            conf_2: configuration of multiconfig lookup table of the second sequence
            prop_start_surf_1: if 0 the propagation for the first sequence will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            prop_start_surf_2: if 0 the propagation for the second sequence will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
        """
    def getBeamletPropagationPSFComplex(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, prop_start_surf: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float) -> ImageObjectC: 
        """
        Returns an ImageObjectC containing the complex amplitude of the point spread function computed via GBD.
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            prop_start_surf: if 0 the propagation will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
        """
    def getBeamletPropagationPSFIntensity(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, prop_start_surf: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the point spread function computed via GBD.
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            prop_start_surf: if 0 the propagation will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
        """
    def getBeamletPropagationThroughFocusPSFComplex(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, prop_start_surf: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float) -> ImageObjectC: 
        """
        Returns an ImageObjectC containing the complex amplitude of the through focus point spread function in the Y-Z plane computed via GBD.
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            prop_start_surf: if 0 the propagation will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
        """
    def getBeamletPropagationThroughFocusPSFIntensity(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, prop_start_surf: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the through focus point spread function in the Y-Z plane computed via GBD.
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            prop_start_surf: if 0 the propagation will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
        """
    def getComplexAmplitude(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> DataObject1C: 
        """
        Returns a DataObject1C containing the complex amplitude of the rays.
        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the phase is not the absolute OPL but the corrected OPL in the exit pupil location.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getCurrentConfig(self) -> int: 
        """
        Returns the current active realisation value the multiconfig lookuptable
        is set to in the model.
        """
    def getCurrentFileName(self) -> str: 
        """
        Returns the filename of the currently opend Quadoa model file
        """
    def getCurrentFolderName(self) -> str: 
        """
        Returns the path to the folder where the currently opend Quadoa model file is located
        """
    def getCurrentMulticonfParam(self, param_name: str) -> float: 
        """
        Returns the value of a parameter inside the multiconfig lookuptable
        for the current active realisation specified by the name.

        Args:
            param_name: name of the multiconfig parameter
        """
    def getEField(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int, type: polarInteractionType) -> DataObject3C: 
        """
        Returns a DataObject3C containing the 3D complex electric field at a surface.

        A polarization raytrace needs to be performed prior to calling this method.
        Also polarization needs to be enabled for the source of the sequence.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index nr of the surface
            type: interaction type where to obtain the polarization state
        """
    def getEffectiveFNumber(self, seq_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the effective F-Number for a given sequence / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getEffectiveFocalLength(self, seq_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the effective focal length for a given sequence / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getEntrancePupilDiameter(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the entrance pupil diameter for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getEnvironmentWavelength(self, seq_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the environment wavelength for a specific sequence / wavelength combination.
        The environment wavelengt is the wavelengh that is entered in the source definition.
        It is always defined in the environment defined in the environment definition for a temperature and pressure.

        The wavelength can be changed with setWaveLength()

        Args:
            seq_nr: index of the sequence
            wavelength_nr: index of the wavelength
        """
    def getExitPupilDiameter(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the entrance pupil diameter for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getFFTMTF(self, seq_nr: int, field_nr: int, wavelength_nr: int, grid_size: int, image_size: int) -> DataObject4D: 
        """
        Returns an DataObject4D containing the modulation transfer function computed via FFT.

        Each row in the DataObject represents the values of the MTF for the following directions:
        Row 0: linepairs in mm in radial direction
        Row 1: modulation transfer value in radial direction
        Row 2: linepairs in mm in tangential direction
        Row 3: modulation transfer value in tangential direction

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
        """
    def getFFTPSF(self, seq_nr: int, field_nr: int, wavelength_nr: int, grid_size: int, image_size: int) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the point spread function computed via FFT.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr index of the wavelength:
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
        """
    def getFFTPSFPolychrom(self, seq_nr: int, field_nr: int, grid_size: int, image_size: int) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the polychromatic point spread function computed via FFT.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
        """
    def getFiberCouplingEfficiencyBeamletPropagationPSFGaussianModeByMFD(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, fiber_MFD: float, prop_start_surf: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a single mode fiber with a gaussian mode where the fiber is specified by its mode field diameter (MFD) and the overlap integral is evaluated on the fiber surface
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            fiber_MFD: 1/e^2 mode field diameter (MFD) of the fiber
            prop_start_surf: if 0 the propagation will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyBeamletPropagationPSFGaussianModeByNA(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, fiber_NA: float, prop_start_surf: int, objSampling: int, imageSampling: int, imageScale: float, oversample: float, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a single mode fiber with a gaussian mode where the fiber is specified by its numerical aperture and the overlap integral is evaluated on the fiber surface
        (This function requires a licens for the Quadoa Wave Optics Toolbox)

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            fiber_NA: 1/e^2 numerical aperture of the fiber
            prop_start_surf: if 0 the propagation will directly start at the object surface, if > 0 the rays will be traced to this surface and then propagated from there
            objSampling: grid sampling / number of beamlets in x and y direction
            imageSampling: grid sampling / number of pixels in x and y direction in image space
            imageScale: scale of the area in the image space to evaluate (in mm)
            oversample: oversampling of the beamlets
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyHuyPSFGaussianModeByMFD(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, fiber_MFD: float, pupilSampling: int, imageSampling: int, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a single mode fiber with a gaussian mode where the fiber is specified by its mode field diameter (MFD) and the overlap integral is evaluated on the fiber surface

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            fiber_MFD: 1/e^2 mode field diameter (MFD) of the fiber
            pupilSampling: sampling of rays in the pupil in x and y direction
            imageSampling: sampling of pixels on the fiber surface in x and y direction
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyHuyPSFGaussianModeByNA(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, fiber_NA: float, pupilSampling: int, imageSampling: int, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a single mode fiber with a gaussian mode where the fiber is specified by its numerical aperture and the overlap integral is evaluated on the fiber surface

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            fiber_NA: 1/e^2 numerical aperture of the fiber
            pupilSampling: sampling of rays in the pupil in x and y direction
            imageSampling: sampling of pixels on the fiber surface in x and y direction
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyMultimodeByIndex(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, index_core: float, index_cladd: float, dia_core: float, incl_fresnel: bool, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a multimode fiber where the fiber is specified by the NA.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            index_core: refractive index of the fiber core
            index_cladd: refractive index of the fiber cladding
            dia_core: fiber core diameter
            incl_fresnel: include the Fresnell losses at the fiber surface in the calculation
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyMultimodeByNA(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, index_core: float, NA: float, dia_core: float, incl_fresnel: bool, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a multimode fiber where the fiber is specified by the NA.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            index_core: refractive index of the fiber core
            NA: fiber numerical aperture (maximal acceptance angle)
            dia_core: fiber core diameter
            incl_fresnel: include the Fresnell losses at the fiber surface in the calculation
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyPupilFunctionGaussianModeByMFD(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, fiber_MFD: float, pupilSampling: int, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a single mode fiber with a gaussian mode where the fiber is specified by its mode field diameter (MFD) and the overlap integral is evaluated in the exit pupuil plane

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            fiber_MFD: 1/e^2 mode field diameter (MFD) of the fiber
            pupilSampling: sampling of rays in the pupil in x and y direction
            incl_sys: include the in system losses in the calculation
        """
    def getFiberCouplingEfficiencyPupilFunctionGaussianModeByNA(self, seq_nr: int, field_nr: int, wavelength_nr: int, conf: int, fiber_NA: float, pupilSampling: int, incl_sys: bool) -> float: 
        """
        Returns the fiber coupling efficiency of a single mode fiber with a gaussian mode where the fiber is specified by its numerical aperture and the overlap integral is evaluated in the exit pupuil plane

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength:
            conf: configuration of multiconfig lookup table
            fiber_NA: 1/e^2 numerical aperture of the fiber
            pupilSampling: sampling of rays in the pupil in x and y direction
            incl_sys: include the in system losses in the calculation
        """
    def getFieldDecenterX(self, seq_nr: int, field_nr: int) -> float: 
        """
        Returns the field decenter in x direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of decenter
        (see getFieldType()).

        The tilt can be changed with setFieldDecenterX()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
        """
    def getFieldDecenterY(self, seq_nr: int, field_nr: int) -> float: 
        """
        Returns the field decenter in y direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of decenter
        (see getFieldType()).

        The tilt can be changed with setFieldDecenterY()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
        """
    def getFieldTiltX(self, seq_nr: int, field_nr: int) -> float: 
        """
        Returns the field tilt in x direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of tilt
        (see getFieldType()).

        The tilt can be changed with setFieldTiltX()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
        """
    def getFieldTiltY(self, seq_nr: int, field_nr: int) -> float: 
        """
        Returns the field tilt in y direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of tilt
        (see getFieldType()).

        The tilt can be changed with setFieldTiltY()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
        """
    def getFieldType(self, seq_nr: int) -> sequenceFieldType: 
        """
        Returns the type of the field definition for a sequence specified by seq_nr.

        The field type type can be changed by setFieldType()

        Args:
            seq_nr: index of the sequence
        """
    def getFirstError(self) -> str: 
        """
        Returns a string containing information about the first error.
        If there are no errors a empty string is returned.
        """
    def getFirstWarning(self) -> str: 
        """
        Returns a string containing information about the first warning.
        If there are no errors a empty string is returned.
        """
    def getFootPrintType(self, seq_nr: int) -> distributionFootprintType: 
        """
        Returns the footprint type definition for a sequence specified by seq_nr.

        The footprint type can be changed by setFootPrintType()

        Args:
            seq_nr: index of the sequence
        """
    def getFullVersionInfoString(self) -> str: 
        """
        Returns a string containing information about the Quaoda library version.
        """
    def getGeoMTF(self, seq_nr: int, field_nr: int, wavelength_nr: int, image_size: int) -> DataObject4D: 
        """
        Returns an DataObject4D containing the modulation transfer function computed for the geometric spot diagram.

        Each row in the DataObject represents the values of the MTF for the following directions:
        Row 0: linepairs in mm in radial direction
        Row 1: modulation transfer value in radial direction
        Row 2: linepairs in mm in tangential direction
        Row 3: modulation transfer value in tangential direction

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
            image_size: grid for image rasterization
        """
    def getGeoPSF(self, seq_nr: int, field_nr: int, wavelength_nr: int, image_size: int) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the point spread function computed for the geometric spot diagram.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
            image_size: grid for image rasterization
        """
    def getGeoPSFPolychrom(self, seq_nr: int, field_nr: int, image_size: int) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the polychromatic point spread function computed for the geometric spot diagram.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            image_size: grid for image rasterization
        """
    def getGlobalRayDirExit(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a getGlobalRayDirExit containing the (x, y, z) exit ray direction vector
        of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the global coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getGlobalRayDirIncident(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) incident ray direction vector
        of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the global coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getGlobalRayPos3D(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) position of the rays
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the global coordinate system.
        The 4th cooridinate is always 1.0

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getHuyMTF(self, seq_nr: int, field_nr: int, wavelength_nr: int, grid_size: int, image_size: int, image_scale: float) -> DataObject4D: 
        """
        Returns an DataObject4D containing the modulation transfer function computed via Huygens integral.

        Each row in the DataObject represents the values of the MTF for the following directions:
        Row 0: linepairs in mm in radial direction
        Row 1: modulation transfer value in radial direction
        Row 2: linepairs in mm in tangential direction
        Row 3: modulation transfer value in tangential direction

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
            image_scale: size of the area on the image plain to simulate
        """
    def getHuyPSF(self, seq_nr: int, field_nr: int, wavelength_nr: int, grid_size: int, image_size: int, image_scale: float) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the point spread function computed via Huygens integral.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
            image_scale: size of the area on the image plain to simulate
        """
    def getHuyPSFPolychrom(self, seq_nr: int, field_nr: int, grid_size: int, image_size: int, image_scale: float) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the polychromatic point spread function computed via Huygens integral.

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
            image_scale: size of the area on the image plain to simulate
        """
    def getImgSpaceFNumber(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the image space F-Number for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getImgSpaceNA(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the object space Numerical Aperture for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getIrradianceImageIncoherent(self, seq_nr: int, field_nr: int, wavelength_nr: int, grid_size: int) -> ImageObjectD: 
        """
        Returns an ImageObjectD containing the irradiance map of the rays on the image surface.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            grid_size: number of pixels in image plane (same for x and y-direction)
        """
    def getIrradianceOfSpotArea(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the sum of the flux of all rays of a specific sequence/field/wavelength divided by the spot area in image space.

        Args:
            seq_nr: index nr of the sequence
            filed_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getMajorVersion(self) -> int: 
        """
        Returns the major version number of the Quadoa library.
        """
    def getMaxNrFields(self) -> int: 
        """
        Returns the maximum number of fields defined for any inside the current model.
        """
    def getMaxNrWavelengths(self) -> int: 
        """
        Returns the maximum number of wavelengths defined for any inside the current model.
        """
    def getMeritVector(self, merit_nr: int) -> DataObject1D: 
        """
        Returns the current vector of the merit function values for all
        optimization goals in the Meritfunction specified by merit_nr
        Args:
            merit_nr: index of merit function
        """
    def getMinorVersion(self) -> int: 
        """
        Returns the minor version number of the Quadoa library.
        """
    def getMulticonfParam(self, param_name: str, config: int) -> float: 
        """
        Returns the value of a parameter inside the multiconfig lookup
        table specified by the name and configuration.

        Args:
            param_name: name of the multiconfig param to edit
            config: config for whitch the param will be set
        """
    def getNrConfigs(self) -> int: 
        """
        Returns the number of multiconfig lookuptable configurations in a model.
        """
    def getNrFields(self, seq_nr: int) -> int: 
        """
        Returns the number of fields for a given sequence defined by seq_nr

        Args:
            seq_nr: index of the sequence
        """
    @staticmethod
    def getNrItems(*args, **kwargs) -> typing.Any: 
        """
        Returns the total amount of items of a specific type in the optical design editor.

        Args:
            type: treeItemType enum specifies item type
        """
    def getNrRays(self, seq_nr: int) -> int: 
        """
        Returns the number of rays to be traced for each field and wavelegth
        for a given sequence defined by seq_nr.

        The count depends on the distribution type as well the settings of the distribution.
        See setRayDistributionType(), setRayDistributionCount1() and setRayDistributionCount2();

        Args:
            seq_nr: index of the sequence
        """
    def getNrSurfaces(self, seq_nr: int) -> int: 
        """
        Returns the number of surfaces for a given sequence defined by seq_nr

        Args:
            seq_nr: index of the sequence
        """
    def getNrTotalItems(self) -> int: 
        """
        Returns the total amount of items (rows) in the optical design editor.
        """
    def getNrWavelengths(self, seq_nr: int) -> int: 
        """
        Returns the number of wavelengths for a given sequence defined by seq_nr

        Args:
            seq_nr: index of the sequence
        """
    def getNumberActiveVariables(self, merit_nr: int) -> int: 
        """
        Returns the number of currently active variables for the merit function specified by merit_nr.

        Args:
            merit_nr: index of the merit function
        """
    def getNumberTargets(self, merit_nr: int) -> int: 
        """
        Returns the number of optimization targets that are defined
        for the merit function specified by merit_nr.

        Args:
            merit_nr: index of the merit function
        """
    def getOPDChiefReferenceType(self, seq_nr: int) -> sequenceOPDChiefRefType: 
        """
        Returns the type of the OPD chief reference type definition for a sequence specified by seq_nr.

        The OPD chief reference type type can be changed by setOPDChiefReferenceType()

        Args:
            seq_nr: index of the sequence
        """
    def getOPDReferenceType(self, seq_nr: int) -> sequenceOPDRefType: 
        """
        Returns the type of the OPD reference type definition for a sequence specified by seq_nr.

        The OPD reference type type can be changed by setOPDReferenceType()

        Args:
            seq_nr: index of the sequence
        """
    def getOPL(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the absolute optical path length of the rays.
        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The returned OPL is not the absolute OPL but the corrected OPL in the exit pupil location.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getObjSpaceFNumber(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the object space F-Number for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getObjSpaceNA(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the object space Numerical Aperture for a given sequence / field / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def getOpticalSystemElementRowNrByID(self, id: str) -> int: 
        """
        Returns the row number of an item in the optical design editor that matches the specified ID.

        Args:
             id: string containing the ID of the item
        """
    def getOpticalSystemElementSurfaceRowNrByID(self, id: str, surf_nr: int) -> int: 
        """
        Returns the row number of a surface of a element or lens in the optical design editor that matches the specified ID and surface number.

        Args:
            id: string containing the ID of the item
            surf_nr: index of the surface in the element or lens
        """
    def getOpticalSystemParamByIDB(self, row_nr: int, param_name: str) -> bool: 
        """
        Returns the value of a boolean parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
        """
    def getOpticalSystemParamByIDC(self, row_nr: int, param_name: str) -> str: 
        """
        Returns the value of a string parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
        """
    def getOpticalSystemParamByIDD(self, row_nr: int, param_name: str) -> float: 
        """
        Returns the value of a double parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
        """
    def getOpticalSystemParamByIDI(self, row_nr: int, param_name: str) -> int: 
        """
        Returns the value of a integer parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
        """
    def getOpticalSystemParamByIndexB(self, row_nr: int, col_nr: int) -> bool: 
        """
        Returns the value of a boolean parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
        """
    def getOpticalSystemParamByIndexC(self, row_nr: int, col_nr: int) -> str: 
        """
        Returns the value of a string parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
        """
    def getOpticalSystemParamByIndexD(self, row_nr: int, col_nr: int) -> float: 
        """
        Returns the value of a double parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
        """
    def getOpticalSystemParamByIndexI(self, row_nr: int, col_nr: int) -> int: 
        """
        Returns the value of a integer parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
        """
    def getOpticalSystemParamTypeByID(self, row_nr: int, param_name: str) -> paramType: 
        """
        Returns the type of a parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
        """
    def getOpticalSystemParamTypeByIndex(self, row_nr: int, col_nr: int) -> paramType: 
        """
        Returns the type of a parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
        """
    def getOpticalSystemVariableStateByID(self, row_nr: int, param_name: int, merit_nr: str) -> bool: 
        """
        Returns the activation state of a variable parameter at
        a given row_nr matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
            merit_nr: index of the merit function
        """
    def getOpticalSystemVariableStateByIndex(self, row_nr: int, col_nr: int, merit_nr: int) -> bool: 
        """
        Returns the activation state of a variable parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
            merit_nr: index of the merit function
        """
    def getOptimizerResidualRMSValue(self, merit_nr: int) -> float: 
        """
        Returns the current value of the merit function specified by merit_nr.

        Args:
            merit_nr: index of the merit function
        """
    def getParticularSurfFormByRow(self, row_nr: int, form_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate of the form contribution of
        a single surface form in the local surface coordinate system.
        The 4th cooridinate is always 1.0

        Args:
            row_nr: index row number of surface in tree
            form_nr: index nr of the form
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getParticularSurfFormBySequence(self, seq_nr: int, surf_nr: int, form_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate of the form contribution of
        a single surface form in the local surface coordinate system.
        The 4th cooridinate is always 1.0

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
            form_nr: index nr of the form
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getParticularSurfPhaseByRow(self, row_nr: int, phase_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate of the form contribution of
        a single surface form in the local surface coordinate system.
        The 4th cooridinate is always 1.0

        Args:
            row_nr: index row number of surface in tree
            phase_nr: index nr of the phase
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getParticularSurfPhaseBySequence(self, seq_nr: int, surf_nr: int, phase_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate of the form contribution of
        a single surface form in the local surface coordinate system.
        The 4th cooridinate is always 1.0

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
            phase_nr: index nr of the phase
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getPolarizationEllipticity(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int, type: polarInteractionType, ref: polarReferenceCoo) -> DataObject1D: 
        """
        Returns a DataObject1D containing the ellipticity of the polarization state at a surface.

        A polarization raytrace needs to be performed prior to calling this method.
        Also polarization needs to be enabled for the source of the sequence.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index nr of the surface
            type: interaction type where to obtain the polarization state.
            ref: reference for the projection of the 3D E-Field to the surface
        """
    def getPolarizationJones(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int, type: polarInteractionType, ref: polarReferenceCoo) -> DataObject2C: 
        """
        Returns a DataObject2C containing the 2D-polarization state at a surface.

        A polarization raytrace needs to be performed prior to calling this method.
        Also polarization needs to be enabled for the source of the sequence.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index nr of the surface
            type: interaction type where to obtain the polarization state.
            ref: reference for the projection of the 3D E-Field to the surface
        """
    def getPolarizationOrientation(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int, type: polarInteractionType, ref: polarReferenceCoo) -> DataObject1D: 
        """
        Returns a DataObject1D containing the orientation of the polarization state at a surface.

        A polarization raytrace needs to be performed prior to calling this method.
        Also polarization needs to be enabled for the source of the sequence.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index nr of the surface
            type: interaction type where to obtain the polarization state.
            ref: reference for the projection of the 3D E-Field to the surface
        """
    def getPolarizationStokes(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int, type: polarInteractionType, ref: polarReferenceCoo) -> DataObject4D: 
        """
        Returns a DataObject4D containing the Stokes parameters of the field at a surface.

        A polarization raytrace needs to be performed prior to calling this method.
        Also polarization needs to be enabled for the source of the sequence.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index nr of the surface
            type: interaction type where to obtain the polarization state
            ref: reference for the projection of the 3D E-Field to the surface
        """
    def getPolarizationType(self, seq_nr: int) -> sequencePolarizationType: 
        """
        Returns the type of the polarization definition for a sequence specified by seq_nr.

        The polarization type can be changed by setPolarizationType()

        Args:
            seq_nr: index of the sequence
        """
    def getRayDirExit(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) exit ray direction vector of the rays
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getRayDirIncident(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) incident ray direction vector
        of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getRayDistributionCount1(self, seq_nr: int) -> int: 
        """
        Returns the first parameter that specifies the ray density of a distribution type for a sequence specified by seq_nr.

        The meaning of this parameter depends on the selected distribution type (see getRayDistributionType())
        Depending on the distribution type selected, this parameter may have no meaning

        It can be changed by setRayDistributionCount1()

        Args:
            seq_nr: index of the sequence
        """
    def getRayDistributionCount2(self, seq_nr: int) -> int: 
        """
        Returns the second parameter that specifies the ray density of a distribution type for a sequence specified by seq_nr.

        The meaning of this parameter depends on the selected distribution type (see getRayDistributionType())
        Depending on the distribution type selected, this parameter may have no meaning

        It can be changed by setRayDistributionCount2()

        Args:
            seq_nr: index of the sequence
        """
    def getRayDistributionType(self, seq_nr: int) -> sequenceDistributionType: 
        """
        Returns the type of the ray distribution. Depending ont the type different kind of grids,
        fans, random distributions and so on can be specified.

        The density of the grid can be specified with setRayDistributionCount1() and setRayDistributionCount2()
        It can be changed by setRayDistributionType()

        Args:
            seq_nr: index of the sequence
        """
    def getRayPos(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject2D: 
        """
        Returns a DataObject2D containing the (x, y)-position of the rays
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getRayPos3D(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) position of the rays
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.
        The 4th cooridinate is always 1.0

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getRayPosOnOPDReferenceSurface(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> DataObject2D: 
        """
        Returns a DataObject2D containing the (x, y)-position of the rays
        of a specific sequence, field and wavelenght
        on the OPD reference surface which is typically the exit pupil.
        In case of sequenceOPDRefType absOverImageSurf it is the image e surface.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getSeidelCoefficient(self, seq_nr: int, wavelength_nr: int, seidel: seidelAberration, type: seidelType) -> float: 
        """
        Returns the seidel coefficient specifiedy by the parameters seidel and type for a given sequence / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            wavelength_nr: index nr of the wavelength to be traced
            seidel: enum that defines the seidel coefficient to return
            type: tpye of the seidel coefficient (S1,S2,...) or wavefront error (W040, ...)
        """
    def getSeidelCoefficientForSurface(self, seq_nr: int, wavelength_nr: int, surf_nr: int, seidel: seidelAberration, type: seidelType) -> float: 
        """
        Returns the seidel contribution of a singel surface specifiedy by the parameters seidel and type for a given sequence / wavelength.

        Args:
            seq_nr: index nr of the sequence to be traced
            wavelength_nr: index nr of the wavelength to be traced
            surf_nr: index nr of the surface in the sequence
            seidel: enum that defines the seidel coefficient to return
            type: tpye of the seidel coefficient (S1,S2,...) or wavefront error (W040, ...)
        """
    def getSequenceImageSpaceType(self, seq_nr: int) -> sequenceImageSpaceType: 
        """
        Returns the type image space type definition for a sequence specified by seq_nr.

        The source type can be changed by setSequenceImageSpaceType()

        Args:
            seq_nr: index of the sequence
        """
    def getSequenceImageSurface(self, seq_nr: int) -> int: 
        """
        Returns the index of the last surface inside the sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
        """
    def getSequenceStopSurface(self, seq_nr: int) -> int: 
        """
        Returns the index of the stop surface inside the sequence specified by seq_nr.

        If the sequence aperture type does not rely on a stop surface this parameter has no meaning.

        It can be changed by setSequenceStopSurface()

        Args:
            seq_nr: index of the sequence
        """
    def getSingleGlobalConstraintDisplayValue(self, merit_nr: int, target_nr: int) -> float: 
        """
        Returns the current value of a single global optimization constraint in a meritfunction
        Args:
            merit_nr: index of merit function
            target_nr: index of target
        """
    def getSingleGlobalConstraintName(self, merit_nr: int, target_nr: int) -> str: 
        """
        Returns the type-string of a single global optimization constraint in a meritfunction
        Args:
            merit_nr: index of merit function
            target_nr: index of target
        """
    def getSingleGlobalGoalDisplayValue(self, merit_nr: int, target_nr: int) -> float: 
        """
        Returns the current value of a single global optimization goal in a meritfunction
        Args:
            merit_nr: index of merit function
            target_nr: index of target
        """
    def getSingleGlobalGoalName(self, merit_nr: int, target_nr: int) -> str: 
        """
        Returns the type-string of a single global optimization goal in a meritfunction
        Args:
            merit_nr: index of merit function
            target_nr: index of target
        """
    def getSingleRayTraceConstraintDisplayValue(self, merit_nr: int, raytrace_nr: int, target_nr: int) -> float: 
        """
        Returns the current value of a single raytrace optimization constraint in a meritfunction
        Args:
            merit_nr: index of merit function
            raytrace_nr: index of raytrace
            target_nr: index of target
        """
    def getSingleRayTraceConstraintName(self, merit_nr: int, raytrace_nr: int, target_nr: int) -> str: 
        """
        Returns the type-string of a single raytrace optimization constraint in a meritfunction
        Args:
            merit_nr: index of merit function
            raytrace_nr: index of raytrace
            target_nr: index of target
        """
    def getSingleRayTraceGoalDisplayValue(self, merit_nr: int, raytrace_nr: int, target_nr: int) -> float: 
        """
        Returns the current value of a single raytrace optimization goal in a meritfunction
        Args:
            merit_nr: index of merit function
            raytrace_nr: index of raytrace
            target_nr: index of target
        """
    def getSingleRayTraceGoalName(self, merit_nr: int, raytrace_nr: int, target_nr: int) -> str: 
        """
        Returns the type-string of a single raytrace optimization goal in a meritfunction
        Args:
            merit_nr: index of merit function
            raytrace_nr: index of raytrace
            target_nr: index of target
        """
    def getSourceType(self, seq_nr: int) -> sequenceSourceType: 
        """
        Returns the type of the OPD reference type definition for a sequence specified by seq_nr.

        The source type can be changed by setSourceType()

        Args:
            seq_nr: index of the sequence
        """
    def getStrehlRatio(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the strehl ratio for a given sequence / field / wavelength estimdated from the wavefront error
        For more accurate results getStrehlRatioHuy() is to be preferred

        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
        """
    def getStrehlRatioHuy(self, seq_nr: int, field_nr: int, wavelength_nr: int, grid_size: int, image_size: int, image_scale: float) -> float: 
        """
        Returns the strehl ratio for a given sequence / field / wavelength by computing a Huygens PSF.
        See also getStrehlRatio()
        Args:
            seq_nr: index of the squence
            field_nr: index of the field
            wavelength_nr: index of the wavelength
            grid_size: grid for pupil rasterization
            image_size: grid for image rasterization
            image_scale: size of the area on the image plain to simulate
        """
    def getSurfBaseXByRow(self, row_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) vector of
        the local surface coordinate systems X-axis direction in the global coordinate system.

        Args:
            row_nr: index row number of surface in tree
        """
    def getSurfBaseXBySequence(self, seq_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) vector of
        the local surface coordinate systems X-axis direction in the global coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
        """
    def getSurfBaseYByRow(self, row_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) vector of
        the local surface coordinate systems Y-axis direction in the global coordinate system.

        Args:
            row_nr: index row number of surface in tree
        """
    def getSurfBaseYBySequence(self, seq_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) vector of
        the local surface coordinate systems Y-axis direction in the global coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
        """
    def getSurfBaseZByRow(self, row_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) vector of
        the local surface coordinate systems Z-axis direction in the global coordinate system.

        Args:
            row_nr: index row number of surface in tree
        """
    def getSurfBaseZBySequence(self, seq_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) vector of
        the local surface coordinate systems Z-axis direction in the global coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
        """
    def getSurfFormByRow(self, row_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate
        of the surface form in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfFormBySequence(self, seq_nr: int, surf_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate
        of the surface form in the local surface coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfGradByRow(self, row_nr: int, grid_size: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the (2d) gradient
        of the surface form in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfOriginByRow(self, row_nr: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z, 1.0) coordinate of
        the surface origin in the global coordinate system.

        Args:
            row_nr: index row number of surface in tree
        """
    def getSurfOriginBySequence(self, seq_nr: int, surf_nr: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z, 1.0) coordinate of
        the surface origin in the global coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
        """
    def getSurfPhaseByRow(self, row_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate
        of the surface phase in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfPhaseBySequence(self, seq_nr: int, surf_nr: int, grid_size: int) -> DataObject4D: 
        """
        Returns a DataObject4D containing the (x, y, z) coordinate
        of the surface phase in the local surface coordinate system.

        Args:
            seq_nr: index nr of the sequence
            surf_nr: index nr of the surface
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfPhaseGradByRow(self, row_nr: int, grid_size: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the (2D) gradient
        of the surface phase in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfPhaseXGradByRow(self, row_nr: int, grid_size: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the gradient in x direction
        of the surface phase in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfPhaseYGradByRow(self, row_nr: int, grid_size: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the gradient in y direction
        of the surface phase in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfXGradByRow(self, row_nr: int, grid_size: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the gradient  in x direction
        of the surface form in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfYGradByRow(self, row_nr: int, grid_size: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the gradient in y direction
        of the surface form in the local surface coordinate system.

        Args:
            row_nr: index row number of surface in tree
            grid_size: resolution of poins for the grid in x- and y-direction
        """
    def getSurfaceNormalAtRayPos(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject3D: 
        """
        Returns a DataObject3D containing the (x, y, z) surface normal vector
        of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getSurfaceNrInSequenceFromRowNr(self, seq_nr: int, row_nr: int) -> int: 
        """
        Returns the index number of a surface in a sequence based on the row number in the optical design editor.

        Args:
            seq_nr: index of the sequence
            row_nr: row of the surface in the optical design editor
        """
    def getSurfaceRowNrFromSequence(self, seq_nr: int, surf_nr: int) -> int: 
        """
        Returns the row number of a surface in the optical design editor based on the surf_nr in the sequence.

        Args:
            seq_nr: index of the sequence
            surf_nr: index of the surface in the sequence
        """
    def getTotalPowerInImageSpace(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the sum of the flux of all rays of a specific sequence/field/wavelength in image space.

        Args:
            seq_nr: index nr of the sequence
            filed_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getTransmission(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int, before_interaction: bool) -> DataObject1D: 
        """
        Returns an DataObject1D containing the transmission for each ray up to a given surface.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: surface up to which the transmission is evaluated
            before_interaction: if true the transmission is evaluated before the surface interaction
        """
    def getVacuumWavelength(self, seq_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the vacuum wavelength for a specific sequence / wavelength combination.

        The wavelength can be changed with setWaveLength() which takes the environment wavelength as argument.

        Args:
            seq_nr: index of the sequence
            wavelength_nr: index of the wavelength
        """
    def getWaveFrontGrad(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the (2D) gradient of the wavefront
        at the position of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getWaveFrontXGrad(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the gradient in local coordinate system
        x-direction of the wavefront at the position of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getWaveFrontYGrad(self, seq_nr: int, field_nr: int, wavelength_nr: int, surf_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing the gradient in local coordinate system
        y-direction of the wavefront at the position of the rays of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        A raytrace needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            surf_nr: index of the surface inside the sequence
        """
    def getWavelengthWeight(self, seq_nr: int, wavelength_nr: int) -> float: 
        """
        Returns the weight of the wavelength for a specific sequence / wavelength combination.

        The wavelength weight can be changed with setWaveLengthWeight()

        Args:
            seq_nr: index of the sequence
            wavelength_nr: index of the wavelength
        """
    def getZernikeCoefficientsANSIISO(self, seq_nr: int, field_nr: int, wavelength_nr: int, n_coeff: int, rad: float) -> DataObject1D: 
        """
        Returns a DataObject1D containing teh coefficients of a Zernike polynomial fit to the wavefront
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        The sorting of the polynomial is according to the ANSI/ISO sorting.

        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the fit is not the absolute OPL but the corrected OPL in the exit pupil location
        and the x- y-coordinstes for the fit are also take from the exit pupil location.

        A raytrace with a suitable distribution of the rays for the fit is needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            n_coeff: number of zernike coefficients to be used for the fit
            rad: norm radius for the zernike polynomial fit
        """
    def getZernikeCoefficientsANSIISONormRadFromAperture(self, seq_nr: int, field_nr: int, wavelength_nr: int, n_coeff: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing teh coefficients of a Zernike polynomial fit to the wavefront
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        The norm radius is calculated automatically from the aperture of the OPD reference surface.

        The sorting of the polynomial is according to the ANSI/ISO sorting.

        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the fit is not the absolute OPL but the corrected OPL in the exit pupil location
        and the x- y-coordinstes for the fit are also take from the exit pupil location.

        A raytrace with a suitable distribution of the rays for the fit is needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            n_coeff: number of zernike coefficients to be used for the fit
        """
    def getZernikeCoefficientsANSIISONormRadFromRays(self, seq_nr: int, field_nr: int, wavelength_nr: int, n_coeff: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing teh coefficients of a Zernike polynomial fit to the wavefront
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        The norm radius is calculated automatically by the circumcicle arround the rays on the OPD reference surface.

        The sorting of the polynomial is according to the ANSI/ISO sorting.

        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the fit is not the absolute OPL but the corrected OPL in the exit pupil location
        and the x- y-coordinstes for the fit are also take from the exit pupil location.

        A raytrace with a suitable distribution of the rays for the fit is needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            n_coeff: number of zernike coefficients to be used for the fit
        """
    def getZernikeCoefficientsFringe(self, seq_nr: int, field_nr: int, wavelength_nr: int, rad: float) -> DataObject1D: 
        """
        Returns a DataObject1D containing teh coefficients of a Zernike Fringe polynomial fit to the wavefront
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the fit is not the absolute OPL but the corrected OPL in the exit pupil location
        and the x- y-coordinstes for the fit are also take from the exit pupil location.

        A raytrace with a suitable distribution of the rays for the fit is needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
            rad: norm radius for the zernike polynomial fit
        """
    def getZernikeCoefficientsFringeNormRadFromAperture(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing teh coefficients of a Zernike Fringe polynomial fit to the wavefront
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        The norm radius is calculated automatically from the aperture of the OPD reference surface.

        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the fit is not the absolute OPL but the corrected OPL in the exit pupil location
        and the x- y-coordinstes for the fit are also take from the exit pupil location.

        A raytrace with a suitable distribution of the rays for the fit is needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def getZernikeCoefficientsFringeNormRadFromRays(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> DataObject1D: 
        """
        Returns a DataObject1D containing teh coefficients of a Zernike Fringe polynomial fit to the wavefront
        of a specific sequence, field and wavelenght
        on a surface inside the sequence in the local surface coordinate system.

        The norm radius is calculated automatically by the circumcicle arround the rays on the OPD reference surface.

        If the OPDReferenceType is set to ExitPupil (see getOPDReferenceType() and setOPDReferenceType())
        The OPL used for the computation of the fit is not the absolute OPL but the corrected OPL in the exit pupil location
        and the x- y-coordinstes for the fit are also take from the exit pupil location.

        A raytrace with a suitable distribution of the rays for the fit is needs to be performed prior to calling this method.

        Args:
            seq_nr: index nr of the sequence
            field_nr: index nr of the field
            wavelength_nr: index nr of the wavelength
        """
    def hasError(self) -> bool: 
        """
        Returns true is there is an error.
        The error message can be obtained by calling getFirstError().
        """
    def hasWarning(self) -> bool: 
        """
        Returns true is there is a warning.
        The warning message can be obtained by calling getFirstWarning().
        """
    def importCodeVAssembly(self, filename: str, mode: importMode) -> bool: 
        """
        Imports a SEQ file as an assembly into the currently opend model.

        Args:
            filename: the filename of the file to be imported
            mode: import mode (keep or remove dummy surfaces)

        Returns:
        true if success
        """
    def importCodeVModel(self, filename: str, mode: importMode) -> bool: 
        """
        Loads a SEQ file to a new empty model.

        Args:
            filename: the filename of the file to be imported
            mode: import mode (keep or remove dummy surfaces)

        Returns:
        true if success
        """
    def importZMXAssembly(self, filename: str, mode: importMode) -> bool: 
        """
        Imports a ZMX file as an assembly into the currently opend model.

        Args:
            filename: the filename of the file to be imported
            mode: import mode (keep or remove dummy surfaces)

        Returns:
        true if success
        """
    def importZMXModel(self, filename: str, mode: importMode) -> bool: 
        """
        Loads a ZMX file to a new empty model.

        Args:
            filename: the filename of the file to be imported
            mode: import mode (keep or remove dummy surfaces)

        Returns:
        true if success
        """
    def loadCoatingMaterialFile(self, filename: str) -> bool: 
        """
        Loads a coating material file (\*.glas)

        Needs to be called prior to loading a model, so the model can find the coating materials for the optical surfaces.
        This methos can be called several times to load more than one catalog.

        Args:
            filename: the file path to a ``.glas`` material file.
        """
    def loadLensCatalogFile(self, filename: str) -> bool: 
        """
        Loads a lens catalog file (\*.lnct)

        Args:
            filename: the file path to a ``.lnct`` lens catalog file.
        """
    def loadMaterialFile(self, filename: str) -> bool: 
        """
        Loads a material file (\*.glas)

        Needs to be called prior to loading a model, so the model can find the materials for the optical elements.
        This methos can be called several times to load more than one catalog.

        Args:
            filename: the file path to a ``.glas`` material file.
        """
    def loadModelFile(self, filename: str) -> bool: 
        """
        Loads a Quadoa model file (\*.optx)

        To allow Quadoa to find the materials used in the file loadMaterialFile()
        needs to be called prior to loading the model file
        on any material catalog that is used in the model.

        Args:
            filename: the file path to a ``.optx`` model file.

        Returns:
            true if success
        """
    def loadThinFilmFile(self, filename: str) -> bool: 
        """
        Loads a thin film stack file (\*.coat)

        Needs to be called prior to loading a model, so the model can find the coating stack for the optical surfaces.
        This methos can be called several times to load more than one catalog.

        Args:
            filename: the file path to a ``.coat`` material file.
        """
    def newModelFile(self) -> None: 
        """
        Clears the current model that is opened and opens a new empty Quadoa model file
        """
    def nextConfig(self) -> None: 
        """
        Switches the active realisation of the multiconfig lookuptable to the next configuration.
        """
    def optimizeExtendedSync(self, timeout_seconds: float, merit_id: int) -> None: 
        """
        Calls the extended optimizer for a merit function that can be chosen by merit_id.

        Args:
            timeout_seconds: timeout to abort the optimization if it takes too long in seconds
            merit_id: index of the merit function
        """
    def optimizeGlobalSync(self, timeout_seconds: float, merit_id: int) -> None: 
        """
        Calls the global optimizer for a merit function that can be chosen by merit_id.

        Args:
            timeout_seconds: timeout to abort the optimization if it takes too long in seconds
            merit_id: index of the merit function
        """
    def optimizeLocalSync(self, timeout_seconds: float, merit_id: int) -> None: 
        """
        Calls the local optimizer for a merit function that can be chosen by merit_id.

        Args:
            timeout_seconds: timeout to abort the optimization if it takes too long in seconds
            merit_id: index of the merit function
        """
    def optimizeQuickFocusSpotRadius(self, seq_nr: int, dir: int) -> None: 
        """
        Calls the quick focus optimizer to optimize the spotradius by moving the image surface.

        Args:
            seq_nr: index of the sequence to optimize
            dir: diretion to move the image surface (typically z
        """
    def optimizeQuickFocusWaveFront(self, seq_nr: int, dir: int) -> None: 
        """
        Calls the quick focus optimizer to optimize the spotradius by moving the image surface.

             Args:
                 seq_nr: index of the sequence to optimize
                 dir: diretion to move the image surface (typically z
        """
    def previousConfig(self) -> None: 
        """
        Switches the active realisation of the multiconfig lookuptable to the previous configuration.
        """
    def removeAllGhostSequences(self) -> None: 
        """
        Deletes any ghost sequence in the model.
        """
    def saveModelFile(self, filename: str) -> bool: 
        """
        Saves the current model to a Quadoa model file (\*.optx)

        Args:
            filename: the file path to a ``.optx`` model file.

        Returns:
            true if success
        """
    def setApertureType(self, seq_nr: int, type: sequenceApertureType) -> bool: 
        """
        Sets the type of the aperture definition of a sequence specified by seq_nr.

        The current aperture type type can be obtained by getApertureType()

        Args:
            seq_nr: index of the sequence
            type: aperture type to set
        """
    def setApertureValue(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the value of the aperture for a sequence specified by seq_nr.
        Depending on the setting of the aperture type this value may be the NA or the aperture diameter.

        In case of a sequence with floating aperture, where the aperture is defined by the stop surface,
        the value has no meaning"

        The current value can be obtained by getApertureValue()

        Args:
            seq_nr: index of the sequence
            value: new value for the aperture
        """
    def setApodizationExponent(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the exponent of a super gaussian apodization for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationExponentX(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the exponent of an elliptic super gaussian apodization in X-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationExponentY(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the exponent of an elliptic super gaussian apodization in Y-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationSigma(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the standard deviation of a gaussian apodization for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationSigmaX(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the standard deviation of a gaussian apodization in X-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationSigmaY(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the standard deviation of a gaussian apodization in Y-direction for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationTotalPower(self, seq_nr: int, value: float) -> bool: 
        """
        Sets the total power in W of the apodization for a sequence specified by seq_nr.

        Args:
            seq_nr: index of the sequence
            value: value to set
        """
    def setApodizationType(self, seq_nr: int, type: sequenceApodizationType) -> bool: 
        """
        Sets the type of the apodization for a sequence specified by seq_nr.

        The current apodization type can be obtained by getApodizationType()

        Args:
            seq_nr: index of the sequence
            type: apodization type to set
        """
    def setConfig(self, conf: int) -> bool: 
        """
        Switches the active realisation of the multiconfig lookuptable to the specified value.

        Args:
            conf: index to set as curretn multiconfig realisation
        """
    def setCurrentMulticonfParam(self, param_name: str, val: float) -> bool: 
        """
        Sets the value of a parameter inside the multiconfig lookuptable
        for the current active realisation specified by the name.

        Args:
            param_name: name of the multiconfig parameter
            val: value taht will be set to the paramter
        """
    def setFieldDecenterX(self, seq_nr: int, field_nr: int, val: float) -> bool: 
        """
        Sets the field decenter in x direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of decenter.

        The current value can be obtained by getFieldDecenterX()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
            val: new value for the field decenter
        """
    def setFieldDecenterY(self, seq_nr: int, field_nr: int, val: float) -> bool: 
        """
        Sets the field tilt in y direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of tilt.

        The current value can be obtained by getFieldDecenterY()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
            val: new value for the field tilt
        """
    def setFieldTiltX(self, seq_nr: int, field_nr: int, val: float) -> bool: 
        """
        Sets the field tilt in x direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of tilt.

        The current value can be obtained by getFieldTiltX()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
            val: new value for the field tilt
        """
    def setFieldTiltY(self, seq_nr: int, field_nr: int, val: float) -> bool: 
        """
        Sets the field tilt in y direction of a specific field and sequence combination.
        This paramter has onle a meaning when the field type allows the specification of tilt.

        The current value can be obtained by getFieldTiltY()

        Args:
            seq_nr: index of the sequence
            field_nr: index of the field
            val: new value for the field tilt
        """
    def setFieldType(self, seq_nr: int, type: sequenceFieldType) -> bool: 
        """
        Sets the type of the field definition of a sequence specified by seq_nr.

        The current field type type can be obtained by getFieldType()

        Args:
            seq_nr: index of the sequence
            type: field type to set
        """
    def setFootPrintType(self, seq_nr: int, type: distributionFootprintType) -> bool: 
        """
        Sets the type of the footrpint for a sequence specified by seq_nr.

        The current polarization type can be obtained by getFootPrintType()

        Args:
            seq_nr: index of the sequence
            type: footprint type to set
        """
    def setMulticonfParam(self, param_name: str, config: int, val: float) -> bool: 
        """
        Sets the value of a parameter inside the multiconfig lookup
        table specified by the name and configuration.

        Args:
            param_name: name of the multiconfig param to edit
            config: config for whitch the param will be set
            val: value that will be set to the parameter
        """
    def setNrWaveLengths(self, seq_nr: int, n_wav: int) -> bool: 
        """
        Sets the number of differnt wavlengths for a specific sequence

        The value of the wavelengths can be changed with setWaveLength() which takes the environment wavelength as argument.

        Args:
            seq_nr: index of the sequence
            n_wav: number of wavelengths
        """
    def setOPDChiefReferenceType(self, seq_nr: int, type: sequenceOPDChiefRefType) -> bool: 
        """
        Sets the type of the OPD chief reference type of a sequence specified by seq_nr.

        The current OPD chief reference type type can be obtained by getOPDChiefReferenceType()

        Args:
            seq_nr: index of the sequence
            type: OPD chief reference type to set
        """
    def setOPDReferenceType(self, seq_nr: int, type: sequenceOPDRefType) -> bool: 
        """
        Sets the type of the OPD reference type of a sequence specified by seq_nr.

        The current OPD reference type type can be obtained by getOPDReferenceType()

        Args:
            seq_nr: index of the sequence
            type: OPD reference type to set
        """
    def setOpticalSystemExtendedData2D(self, arg0: int, arg1: ImageObjectD) -> bool: 
        """
        Overwrites the extended data of an item at the given row_nr.

        Args:
            row_nr: row index of the item in the tree
            data: ImageObjectD containing the grid data. Dimensions must match allowed format for the items extended data.
            py::arg("row_nr"), py::arg("data"))


        //--------- get data sequence ---------------------------------------------------------------------------------
                .def("getNrSequences", &QOS::QuadoaCore::getNrSequences,
        R"doc(Returns the number of sequences that are defined inside the current model.
        """
    def setOpticalSystemParamByIDB(self, row_nr: int, param_name: str, value: bool) -> bool: 
        """
        Sets the value of a boolean parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
            value: value to set
        """
    def setOpticalSystemParamByIDC(self, row_nr: int, param_name: str, value: str) -> bool: 
        """
        Sets the value of a string parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
            value: value to set
        """
    def setOpticalSystemParamByIDD(self, row_nr: int, param_name: str, value: float) -> bool: 
        """
        Sets the value of a double parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
            value: value to set
        """
    def setOpticalSystemParamByIDI(self, row_nr: int, param_name: str, value: int) -> bool: 
        """
        Sets the value of a integer parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
            value: value to set
        """
    def setOpticalSystemParamByIndexB(self, row_nr: int, col_nr: int, value: bool) -> bool: 
        """
        Sets the value of a boolean parameter at a given
        row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
            value: value to set
        """
    def setOpticalSystemParamByIndexC(self, row_nr: int, col_nr: int, value: str) -> bool: 
        """
        Sets the value of a string parameter at a given
            row_nr and col_nr in the Optical Design Editor.

            Args:
                row_nr: row index of the item in the tree
                col_nr: comumn index of the paramter
                value: value to set
        """
    def setOpticalSystemParamByIndexD(self, row_nr: int, col_nr: int, value: float) -> bool: 
        """
        Sets the value of a double parameter at a given row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
            value: value to set
        """
    def setOpticalSystemParamByIndexI(self, row_nr: int, col_nr: int, value: int) -> bool: 
        """
        Sets the value of a integer parameter at a given
        row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
            value: value to set
        """
    def setOpticalSystemVariableStateByID(self, row_nr: int, param_name: str, merit_nr: int, value: bool) -> bool: 
        """
        Sets the activation state of a variable parameter at a given row_nr
        matching the parameter name in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            param_name: name of the parameter
            merit_nr: index of the merit function
            value: value to set for activation state
        """
    def setOpticalSystemVariableStateByIndex(self, row_nr: int, col_nr: int, merit_nr: int, value: bool) -> bool: 
        """
        Sets the activation state of a variable parameter at a given
        row_nr and col_nr in the Optical Design Editor.

        Args:
            row_nr: row index of the item in the tree
            col_nr: comumn index of the paramter
            merit_nr: index of the merit function
            value: value to set for activation state
        """
    def setPolarizationType(self, seq_nr: int, type: sequencePolarizationType) -> bool: 
        """
        Sets the type of the polarization for a sequence specified by seq_nr.

        The current polarization type can be obtained by getPolarizationType()

        Args:
            seq_nr: index of the sequence
            type: polarization type to set
        """
    def setRayDistributionCount1(self, seq_nr: int, nr_rays: int) -> bool: 
        """
        Sets the first parameter that specifies the ray density of a distribution type for a sequence specified by seq_nr.

        The meaning of this parameter depends on the selected distribution type (see getRayDistributionType())
        Depending on the distribution type selected, this parameter may have no meaning

        The current value can be obtained by getRayDistributionCount1()

        Args:
            seq_nr: index of the sequence
            nr_rays: number of rays to specify the first ray density parameter
        """
    def setRayDistributionCount2(self, seq_nr: int, nr_rays: int) -> bool: 
        """
        Sets the first parameter that specifies the ray density of a distribution type for a sequence specified by seq_nr.

        The meaning of this parameter depends on the selected distribution type (see getRayDistributionType())
        Depending on the distribution type selected, this parameter may have no meaning

        The current value can be obtained by getRayDistributionCount2()

        Args:
            seq_nr: index of the sequence
            nr_rays: number of rays to specify the second ray density parameter
        """
    def setRayDistributionType(self, seq_nr: int, type: sequenceDistributionType) -> bool: 
        """
        Sets the type of the ray distribution. Depending ont the type different kind of grids,
        fans, random distributions and so on can be specified.

        The density of the grid can be specified with setRayDistributionCount1() and setRayDistributionCount2()
        The current value can be obtained by getRayDistributionType()

        Args:
            seq_nr: index of the sequence
            type: distribution type to set
        """
    def setSequenceImageSpaceType(self, seq_nr: int, type: sequenceImageSpaceType) -> bool: 
        """
        Sets the image space type of a sequence specified by seq_nr.

        //The current source type type can be obtained by getSequenceImageSpaceType()

        //Args:
        //    seq_nr: index of the sequence
        //    type: image space type to set
        """
    def setSequenceStopRayPosition(self, seq_nr: int, stop_surf: int, pos: DataObject2D) -> bool: 
        """
        Sets the ray positions on the stop surface for the rayaiming for the sequence specified by seq_nr
        accoring to the (x, y) positions specified by the DataObject2D pos.

        Args:
            seq_nr: index of the sequence
            stop_surf: index of the surface inside the sequence
            pos: DataObject2D containing the position coordinates in the local coordinate surface system
        """
    def setSequenceStopSurface(self, seq_nr: int, surf_nr: int) -> bool: 
        """
        Sets the index of the stop surface inside the sequence specified by seq_nr.

        If the sequence aperture type does not rely on a stop surface this parameter has no meaning.

        The current value can be obtained by getSequenceStopSurface()

        Args:
            seq_nr: index of the sequence
            surf_nr: index of the surface inside the sequence
        """
    def setSourceType(self, seq_nr: int, type: sequenceSourceType) -> bool: 
        """
        Sets the type of the source type of a sequence specified by seq_nr.

        //The current source type type can be obtained by getSourceType()

        //Args:
        //    seq_nr: index of the sequence
        //    type: source type to set
        """
    def setWaveLength(self, seq_nr: int, wave_nr: int, val: float) -> bool: 
        """
        Sets the wavlengths for a specific wavelength for a sequence

        The value of the current wavelengths can be obtained by getEnvironmentWaveLength()

        Args:
            seq_nr: index of the sequence
            n_wav: index of wavelength
            val: wavelength to set
        """
    def setWaveLengthWeight(self, seq_nr: int, wave_nr: int, val: float) -> bool: 
        """
        Sets the wavlengths weight for a specific wavelength for a sequence

        The value of the current wavelengths weight can be obtained by getWaveLengthWeight()

        Args:
            seq_nr: index of the sequence
            n_wav: index of wavelength
            val: wavelength to set
        """
    def sortGhostsByIntensityPerSpotSize(self) -> None: 
        """
        Sorts the ghost sequences according to the maximum energy per area on image surface.
        """
    def sortGhostsByTotalIntensity(self) -> None: 
        """
        Sorts the ghost sequences according to the total energy that will arrive at the image surface.
        """
    def traceAllRays(self) -> bool: 
        """
        Traces all the rays for any sequence, field and wavelenght in the current loaded model.
        A raytrace needs to be performed prior to any method that returns ray data like getRayPos(), getOPL(), ...

        If only data for a specific sequence, field or wavelength is needed traceRays()
        should be used since it will only trace the specified rays.

        The grid of the rays to be traced is the same as visible in the 3D view in the Quadao GUI
        and can be specified using setRayDistributionType() as well as setRayDistributionCount1(),
        setRayDistributionCount2().
        """
    def traceAllRaysInclPupilsAndPolarization(self) -> bool: 
        """
        Traces all the rays for any sequence, field and wavelenght in the current loaded model.
        A polariszation raytrace needs to be performed prior to any method that returns polarization data like getEField(), getPolarization(), ...
        The polarization is only calculated for sequences with polarization enabled in the source.

        The grid of the rays to be traced is the same as visible in the 3D view in the Quadao GUI
        and can be specified using setRayDistributionType() as well as setRayDistributionCount1(),
        setRayDistributionCount2().
        """
    def traceRays(self, seq_nr: int, field_nr: int, wavelength_nr: int) -> bool: 
        """
        Traces a specific set of rays for one sequence, field and wavelenght combination in the current loaded model.
            A raytrace needs to be performed prior to any method that returns ray data like getRayPos(), getOPL(), ...

            The grid of the rays to be traced is the same as visible in the 3D view in the Quadao GUI
            and can be specified using setRayDistributionType() as well as setRayDistributionCount1(),
            setRayDistributionCount2().

        Args:
            seq_nr: index nr of the sequence to be traced
            field_nr: index nr of the field to be traced
            wavelength_nr: index nr of the wavelength to be traced 
        """
    def writeSurfaceFormToXYZ(self, row_nr: int, grid_size: int, filename: str, incl_header: bool, remove_nan: bool) -> bool: 
        """
        Exports the sag of a surface given by its row_nr to csv textfile.

        The file will contain the x, y, z coordinate of the points on the surface.

        Args:
            row_nr: row of the surface in the optical design editor
            grid_size: grid for rasterization in x and y direction
            filename: file to save (e.g. grid.txt or grid.csv)
            inlc_header: include header in file or only coordinate data (bool)
            remove_nan: remove values that are NAN / lie outside the phisical aperture (bool))

        Returns:
            true if success
        """
    def writeSurfacePhaseToXYZ(self, row_nr: int, grid_size: int, filename: str, incl_header: bool, remove_nan: bool) -> bool: 
        """
        Exports the phase of a surface given by its row_nr to csv textfile.

        The file will contain the x, y, z coordinate of the points on the surface.

        Args:
            row_nr: row of the surface in the optical design editor
            grid_size: grid for rasterization in x and y direction
            filename: file to save (e.g. grid.txt or grid.csv)
            inlc_header: include header in file or only coordinate data (bool)
            remove_nan: remove values that are NAN / lie outside the phisical aperture (bool))

        Returns:
            true if success
        """
    pass
class apertureType():
    """
    Enumeration class to specify the type of Surface Aperture objects.

    Members:

      apertureCirc : Circular aperture

      apertureRect : Rectangular aperture

      apertureHex : Hexagonal aperture

      apertureElliptic : Elliptic aperture

      apertureAnnular : Annular aperture

      aperturePolygon : Polygon aperture

      apertureArray : Array operator for apertures. The operator can also be used with Obscurations.

      apertureOr : Or operator for apertures. The operator can also be used with Obscurations.
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'apertureCirc': <apertureType.apertureCirc: 0>, 'apertureRect': <apertureType.apertureRect: 1>, 'apertureHex': <apertureType.apertureHex: 2>, 'apertureElliptic': <apertureType.apertureElliptic: 4>, 'apertureAnnular': <apertureType.apertureAnnular: 5>, 'aperturePolygon': <apertureType.aperturePolygon: 3>, 'apertureArray': <apertureType.apertureArray: 6>, 'apertureOr': <apertureType.apertureOr: 7>}
    apertureAnnular: quadoa.quadoa.apertureType # value = <apertureType.apertureAnnular: 5>
    apertureArray: quadoa.quadoa.apertureType # value = <apertureType.apertureArray: 6>
    apertureCirc: quadoa.quadoa.apertureType # value = <apertureType.apertureCirc: 0>
    apertureElliptic: quadoa.quadoa.apertureType # value = <apertureType.apertureElliptic: 4>
    apertureHex: quadoa.quadoa.apertureType # value = <apertureType.apertureHex: 2>
    apertureOr: quadoa.quadoa.apertureType # value = <apertureType.apertureOr: 7>
    aperturePolygon: quadoa.quadoa.apertureType # value = <apertureType.aperturePolygon: 3>
    apertureRect: quadoa.quadoa.apertureType # value = <apertureType.apertureRect: 1>
    pass
class cadFileType():
    """
    Enumeration class whose members correspond to various CAD file types.

    Members:

      STL : STL file type

      STEP : STEP file type

      IGES : IGES file type
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    IGES: quadoa.quadoa.cadFileType # value = <cadFileType.STEP: 1>
    STEP: quadoa.quadoa.cadFileType # value = <cadFileType.STEP: 1>
    STL: quadoa.quadoa.cadFileType # value = <cadFileType.STL: 0>
    __members__: dict # value = {'STL': <cadFileType.STL: 0>, 'STEP': <cadFileType.STEP: 1>, 'IGES': <cadFileType.STEP: 1>}
    pass
class coatingType():
    """
    Enumeration class to specify the type of Surface Coating objects.

    Members:

      coatingSimple : Simple constant T/R coating

      coatingIdealAR : Ideal AR coating

      coatingIdealMirror : Ideal Mirror coating

      coatingWavelengthDep : Wavelength dependent (interpolated) coating

      coatingAngleDependant : Angle dependent (interpolated) coating

      coatingAngleAndWaveDependant : Angle and Wavelength dependent (bi-linear interpolated) coating

      coatingFullData : Polarization dependant interpolated coating

      coatingPupilPosDependant : Pupil position dependent coating

      coatingThinFilmStack : Thin Film Stack Coating

      coatingArray : Array of coatings over pupil position

      attenuatorConst : Constant Attenuator

      attenuatorGauss : Gaussian Profile Attenuator

      attenuatorCosine : Periodic Profile Attenuator
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'coatingSimple': <coatingType.coatingSimple: 0>, 'coatingIdealAR': <coatingType.coatingIdealAR: 1>, 'coatingIdealMirror': <coatingType.coatingIdealMirror: 2>, 'coatingWavelengthDep': <coatingType.coatingWavelengthDep: 3>, 'coatingAngleDependant': <coatingType.coatingAngleDependant: 4>, 'coatingAngleAndWaveDependant': <coatingType.coatingAngleAndWaveDependant: 5>, 'coatingFullData': <coatingType.coatingFullData: 6>, 'coatingPupilPosDependant': <coatingType.coatingSimple: 0>, 'coatingThinFilmStack': <coatingType.coatingIdealAR: 1>, 'coatingArray': <coatingType.coatingIdealMirror: 2>, 'attenuatorConst': <coatingType.coatingAngleDependant: 4>, 'attenuatorGauss': <coatingType.coatingAngleAndWaveDependant: 5>, 'attenuatorCosine': <coatingType.coatingAngleAndWaveDependant: 5>}
    attenuatorConst: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleDependant: 4>
    attenuatorCosine: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleAndWaveDependant: 5>
    attenuatorGauss: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleAndWaveDependant: 5>
    coatingAngleAndWaveDependant: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleAndWaveDependant: 5>
    coatingAngleDependant: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleDependant: 4>
    coatingArray: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealMirror: 2>
    coatingFullData: quadoa.quadoa.coatingType # value = <coatingType.coatingFullData: 6>
    coatingIdealAR: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealAR: 1>
    coatingIdealMirror: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealMirror: 2>
    coatingPupilPosDependant: quadoa.quadoa.coatingType # value = <coatingType.coatingSimple: 0>
    coatingSimple: quadoa.quadoa.coatingType # value = <coatingType.coatingSimple: 0>
    coatingThinFilmStack: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealAR: 1>
    coatingWavelengthDep: quadoa.quadoa.coatingType # value = <coatingType.coatingWavelengthDep: 3>
    pass
class distributionFootprintType():
    """
    Enumeration class for the definition of the footprint type of the distribution
    of the raysin a sequence.

    Members:

      error : Error value

      onPlane : 

      onSphere : 
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <distributionFootprintType.error: 0>, 'onPlane': <distributionFootprintType.onPlane: 1>, 'onSphere': <distributionFootprintType.onSphere: 2>}
    error: quadoa.quadoa.distributionFootprintType # value = <distributionFootprintType.error: 0>
    onPlane: quadoa.quadoa.distributionFootprintType # value = <distributionFootprintType.onPlane: 1>
    onSphere: quadoa.quadoa.distributionFootprintType # value = <distributionFootprintType.onSphere: 2>
    pass
class formType():
    """
    Enumeration class to specify the type of Surface Forms objects that define the surface sag.

    Members:

      formPlane : Planar Tilt Form

      formSphere : Spherical form

      formZernSymmetric : Zernike polynomials form

      formZernFringe : Zernike Fringe polynomials form

      formXYZPoly : XYZ polynomials form

      formParaboloid : Paraboloid form

      formAsphere : Standard Asphere forms

      formAsphereQCon : QCon Forbes Poly Asphere forms

      formAsphereQBfs : QBfs Forbs Poly Asphere forms

      formAcylinder : Acylinder form

      formAcylinderQCon : Acylinder QCon form

      formAcylinderQBfs : Acylinder QBfs form

      formCylinder : Cylindric form

      formAxicon : Axicon form

      formOffAxisAsphere : Off-Axis Asphere form

      formBiconic : Biconic form

      formTorus : Toroid form

      formCosine : Cosine Form

      formPeriodicRotation : Periodic Rotaion form

      formGaussPeak : Gaussion Peak form

      formGaussPeakSuper : Super Gaussion Peak form

      formGaussPeakElliptic : Elliptic Gaussion Peak form

      formGaussPeakEllipticSuper : Elliptic Gaussion Peak form

      formGaussPeakRectangularSuper : Rectangular Gaussion Peak form

      formInterp : Grid surface form

      formPython : Python surface form

      formOperatorArray : Array operator for form objects

      formOperatorHexArray : Hexagonal array operator for form objects

      formOperatorFresnel : Fresnel operator for form objects

      formManipulationOperator : Manipulation operator for form objects
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'formPlane': <formType.formPlane: 0>, 'formSphere': <formType.formSphere: 1>, 'formZernSymmetric': <formType.formZernSymmetric: 2>, 'formZernFringe': <formType.formZernFringe: 3>, 'formXYZPoly': <formType.formXYZPoly: 4>, 'formParaboloid': <formType.formParaboloid: 8>, 'formAsphere': <formType.formAsphere: 11>, 'formAsphereQCon': <formType.formAsphereQCon: 12>, 'formAsphereQBfs': <formType.formAsphereQBfs: 13>, 'formAcylinder': <formType.formAcylinder: 14>, 'formAcylinderQCon': <formType.formAcylinder: 14>, 'formAcylinderQBfs': <formType.formAcylinder: 14>, 'formCylinder': <formType.formCylinder: 17>, 'formAxicon': <formType.formAxicon: 19>, 'formOffAxisAsphere': <formType.formOffAxisAsphere: 20>, 'formBiconic': <formType.formBiconic: 21>, 'formTorus': <formType.formTorus: 18>, 'formCosine': <formType.formCosine: 22>, 'formPeriodicRotation': <formType.formPeriodicRotation: 23>, 'formGaussPeak': <formType.formGaussPeak: 24>, 'formGaussPeakSuper': <formType.formGaussPeakSuper: 25>, 'formGaussPeakElliptic': <formType.formGaussPeakElliptic: 26>, 'formGaussPeakEllipticSuper': <formType.formGaussPeakEllipticSuper: 27>, 'formGaussPeakRectangularSuper': <formType.formGaussPeakRectangularSuper: 28>, 'formInterp': <formType.formInterp: 29>, 'formPython': <formType.formPython: 30>, 'formOperatorArray': <formType.formOperatorArray: 31>, 'formOperatorHexArray': <formType.formOperatorHexArray: 32>, 'formOperatorFresnel': <formType.formOperatorFresnel: 33>, 'formManipulationOperator': <formType.formManipulationOperator: 34>}
    formAcylinder: quadoa.quadoa.formType # value = <formType.formAcylinder: 14>
    formAcylinderQBfs: quadoa.quadoa.formType # value = <formType.formAcylinder: 14>
    formAcylinderQCon: quadoa.quadoa.formType # value = <formType.formAcylinder: 14>
    formAsphere: quadoa.quadoa.formType # value = <formType.formAsphere: 11>
    formAsphereQBfs: quadoa.quadoa.formType # value = <formType.formAsphereQBfs: 13>
    formAsphereQCon: quadoa.quadoa.formType # value = <formType.formAsphereQCon: 12>
    formAxicon: quadoa.quadoa.formType # value = <formType.formAxicon: 19>
    formBiconic: quadoa.quadoa.formType # value = <formType.formBiconic: 21>
    formCosine: quadoa.quadoa.formType # value = <formType.formCosine: 22>
    formCylinder: quadoa.quadoa.formType # value = <formType.formCylinder: 17>
    formGaussPeak: quadoa.quadoa.formType # value = <formType.formGaussPeak: 24>
    formGaussPeakElliptic: quadoa.quadoa.formType # value = <formType.formGaussPeakElliptic: 26>
    formGaussPeakEllipticSuper: quadoa.quadoa.formType # value = <formType.formGaussPeakEllipticSuper: 27>
    formGaussPeakRectangularSuper: quadoa.quadoa.formType # value = <formType.formGaussPeakRectangularSuper: 28>
    formGaussPeakSuper: quadoa.quadoa.formType # value = <formType.formGaussPeakSuper: 25>
    formInterp: quadoa.quadoa.formType # value = <formType.formInterp: 29>
    formManipulationOperator: quadoa.quadoa.formType # value = <formType.formManipulationOperator: 34>
    formOffAxisAsphere: quadoa.quadoa.formType # value = <formType.formOffAxisAsphere: 20>
    formOperatorArray: quadoa.quadoa.formType # value = <formType.formOperatorArray: 31>
    formOperatorFresnel: quadoa.quadoa.formType # value = <formType.formOperatorFresnel: 33>
    formOperatorHexArray: quadoa.quadoa.formType # value = <formType.formOperatorHexArray: 32>
    formParaboloid: quadoa.quadoa.formType # value = <formType.formParaboloid: 8>
    formPeriodicRotation: quadoa.quadoa.formType # value = <formType.formPeriodicRotation: 23>
    formPlane: quadoa.quadoa.formType # value = <formType.formPlane: 0>
    formPython: quadoa.quadoa.formType # value = <formType.formPython: 30>
    formSphere: quadoa.quadoa.formType # value = <formType.formSphere: 1>
    formTorus: quadoa.quadoa.formType # value = <formType.formTorus: 18>
    formXYZPoly: quadoa.quadoa.formType # value = <formType.formXYZPoly: 4>
    formZernFringe: quadoa.quadoa.formType # value = <formType.formZernFringe: 3>
    formZernSymmetric: quadoa.quadoa.formType # value = <formType.formZernSymmetric: 2>
    pass
class ghostGenFieldWaveType():
    """
    Enumeration class for the definition of the type which fields and wavelenghts are used for ghost sequences.

    Members:

      error : Error value

      firstFieldPrimaryWave : "Only use first field and primary wavelength.

      firstFieldAllWave : Only use first field, but all wavelengths.

      allFieldPrimaryWave : Use all fields, but only primary wavelenght.

      allFieldAllWave : Copy all fields and wavelenghts as they are set in the original sequence.
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <ghostGenFieldWaveType.error: 0>, 'firstFieldPrimaryWave': <ghostGenFieldWaveType.firstFieldPrimaryWave: 1>, 'firstFieldAllWave': <ghostGenFieldWaveType.firstFieldAllWave: 2>, 'allFieldPrimaryWave': <ghostGenFieldWaveType.allFieldPrimaryWave: 3>, 'allFieldAllWave': <ghostGenFieldWaveType.allFieldAllWave: 4>}
    allFieldAllWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.allFieldAllWave: 4>
    allFieldPrimaryWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.allFieldPrimaryWave: 3>
    error: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.error: 0>
    firstFieldAllWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.firstFieldAllWave: 2>
    firstFieldPrimaryWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.firstFieldPrimaryWave: 1>
    pass
class ghostGenRayType():
    """
    Enumeration class for the definition of the type how ray distributions are generated in ghost sequences.

    Members:

      error : Error value

      minimal : This will generate Ghosts with a minimal 5+5 XY-Fan type of ray distribution.

      sameAsSequence : This will generate Ghosts with the same ray distribution as the sequence they are derived from.
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <ghostGenRayType.error: 0>, 'minimal': <ghostGenRayType.minimal: 1>, 'sameAsSequence': <ghostGenRayType.sameAsSequence: 2>}
    error: quadoa.quadoa.ghostGenRayType # value = <ghostGenRayType.error: 0>
    minimal: quadoa.quadoa.ghostGenRayType # value = <ghostGenRayType.minimal: 1>
    sameAsSequence: quadoa.quadoa.ghostGenRayType # value = <ghostGenRayType.sameAsSequence: 2>
    pass
class ghostKeepType():
    """
    Enumeration class for the definition of the method ghosts are filtered after generation.

    Members:

      error : Error value

      worstByMaxIrrad : Filter ghosts by maximum irradiance in the spot area.

      worstByTotalFlux : Filter ghosts by total flux that reaches the image surface.

      keepAll : No filter.
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <ghostKeepType.error: 0>, 'worstByMaxIrrad': <ghostKeepType.worstByMaxIrrad: 1>, 'worstByTotalFlux': <ghostKeepType.worstByTotalFlux: 2>, 'keepAll': <ghostKeepType.keepAll: 3>}
    error: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.error: 0>
    keepAll: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.keepAll: 3>
    worstByMaxIrrad: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.worstByMaxIrrad: 1>
    worstByTotalFlux: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.worstByTotalFlux: 2>
    pass
class importMode():
    """
    Enumeration class for importing 3rd party models

    Members:

      STL : Keep dummy surfaces in the model

      STEP : Remove dummy surfaces if possible
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    STEP: quadoa.quadoa.importMode # value = <importMode.STEP: 2>
    STL: quadoa.quadoa.importMode # value = <importMode.STL: 0>
    __members__: dict # value = {'STL': <importMode.STL: 0>, 'STEP': <importMode.STEP: 2>}
    pass
class obscurationType():
    """
    Enumeration class to specify the type of Surface Obscurations objects.

    Members:

      obscurationCirc : Circular obscuration

      obscurationRect : Rectangular obscuration

      obscurationElliptic : Elliptic obscuration
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'obscurationCirc': <obscurationType.obscurationCirc: 0>, 'obscurationRect': <obscurationType.obscurationRect: 1>, 'obscurationElliptic': <obscurationType.obscurationElliptic: 2>}
    obscurationCirc: quadoa.quadoa.obscurationType # value = <obscurationType.obscurationCirc: 0>
    obscurationElliptic: quadoa.quadoa.obscurationType # value = <obscurationType.obscurationElliptic: 2>
    obscurationRect: quadoa.quadoa.obscurationType # value = <obscurationType.obscurationRect: 1>
    pass
class paramType():
    """
    Type of parameters used in the lens model and sequence definitions.

    Members:

      paramError : Returnded if there is no parameter at given location

      paramDummy : Dummy placeholder parameter

      paramInt : Integer type parameter

      paramString : String type parameter

      paramDouble : Double type parameter

      paramBool : Boolean parameter
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'paramError': <paramType.paramError: 0>, 'paramDummy': <paramType.paramDummy: 1>, 'paramInt': <paramType.paramInt: 2>, 'paramString': <paramType.paramString: 3>, 'paramDouble': <paramType.paramDouble: 4>, 'paramBool': <paramType.paramBool: 5>}
    paramBool: quadoa.quadoa.paramType # value = <paramType.paramBool: 5>
    paramDouble: quadoa.quadoa.paramType # value = <paramType.paramDouble: 4>
    paramDummy: quadoa.quadoa.paramType # value = <paramType.paramDummy: 1>
    paramError: quadoa.quadoa.paramType # value = <paramType.paramError: 0>
    paramInt: quadoa.quadoa.paramType # value = <paramType.paramInt: 2>
    paramString: quadoa.quadoa.paramType # value = <paramType.paramString: 3>
    pass
class phaseType():
    """
    Enumeration class to specify the type of Surface Phase objects.

    Members:

      phaseZernSymmetric : Zernike polynomials phase

      phaseZernFringe : Zernike Fringe polynomials phase

      phaseXYZPoly : XYZ polynomials phase

      phaseGrating : Linear grating phase

      phaseRadial : Radial zone plate phase

      phaseAxial : Axial (Acylindric) phase

      phaseSpiral : Spiral phase

      phaseGaussPeak : Gaussian phase

      phaseGaussPeakSuper : Super Gaussian phase

      phaseGaussPeakElliptic : Elliptic Gaussian phase

      phaseGaussPeakEllipticSuper : Elliptic super Gaussian phase

      phaseGaussPeakRectangularSuper : Rectangular super Gaussian phase

      phaseInterp : Grid phase

      phasePython : Python phase

      phaseOperatorArray : Array operator for phase objects

      phaseOperatorHexArray : Hexagonal array operator for phase objects

      phaseManipulationOperator : Manipulation operator for phase objects
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'phaseZernSymmetric': <phaseType.phaseZernSymmetric: 0>, 'phaseZernFringe': <phaseType.phaseZernFringe: 1>, 'phaseXYZPoly': <phaseType.phaseXYZPoly: 2>, 'phaseGrating': <phaseType.phaseGrating: 3>, 'phaseRadial': <phaseType.phaseRadial: 4>, 'phaseAxial': <phaseType.phaseAxial: 5>, 'phaseSpiral': <phaseType.phaseSpiral: 6>, 'phaseGaussPeak': <phaseType.phaseGaussPeak: 7>, 'phaseGaussPeakSuper': <phaseType.phaseGaussPeakSuper: 8>, 'phaseGaussPeakElliptic': <phaseType.phaseGaussPeakElliptic: 9>, 'phaseGaussPeakEllipticSuper': <phaseType.phaseGaussPeakEllipticSuper: 10>, 'phaseGaussPeakRectangularSuper': <phaseType.phaseGaussPeakRectangularSuper: 11>, 'phaseInterp': <phaseType.phaseInterp: 12>, 'phasePython': <phaseType.phasePython: 13>, 'phaseOperatorArray': <phaseType.phaseOperatorArray: 14>, 'phaseOperatorHexArray': <phaseType.phaseOperatorHexArray: 15>, 'phaseManipulationOperator': <phaseType.phaseManipulationOperator: 16>}
    phaseAxial: quadoa.quadoa.phaseType # value = <phaseType.phaseAxial: 5>
    phaseGaussPeak: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeak: 7>
    phaseGaussPeakElliptic: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakElliptic: 9>
    phaseGaussPeakEllipticSuper: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakEllipticSuper: 10>
    phaseGaussPeakRectangularSuper: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakRectangularSuper: 11>
    phaseGaussPeakSuper: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakSuper: 8>
    phaseGrating: quadoa.quadoa.phaseType # value = <phaseType.phaseGrating: 3>
    phaseInterp: quadoa.quadoa.phaseType # value = <phaseType.phaseInterp: 12>
    phaseManipulationOperator: quadoa.quadoa.phaseType # value = <phaseType.phaseManipulationOperator: 16>
    phaseOperatorArray: quadoa.quadoa.phaseType # value = <phaseType.phaseOperatorArray: 14>
    phaseOperatorHexArray: quadoa.quadoa.phaseType # value = <phaseType.phaseOperatorHexArray: 15>
    phasePython: quadoa.quadoa.phaseType # value = <phaseType.phasePython: 13>
    phaseRadial: quadoa.quadoa.phaseType # value = <phaseType.phaseRadial: 4>
    phaseSpiral: quadoa.quadoa.phaseType # value = <phaseType.phaseSpiral: 6>
    phaseXYZPoly: quadoa.quadoa.phaseType # value = <phaseType.phaseXYZPoly: 2>
    phaseZernFringe: quadoa.quadoa.phaseType # value = <phaseType.phaseZernFringe: 1>
    phaseZernSymmetric: quadoa.quadoa.phaseType # value = <phaseType.phaseZernSymmetric: 0>
    pass
class polarInteractionType():
    """
    Enumeration class to specify at which step of the interaction the polarization state should be observed.

    Members:

      error : Error value

      before : Before the interation with the surface

      after : After the interaction with the surface
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <polarInteractionType.error: 0>, 'before': <polarInteractionType.before: 1>, 'after': <polarInteractionType.after: 2>}
    after: quadoa.quadoa.polarInteractionType # value = <polarInteractionType.after: 2>
    before: quadoa.quadoa.polarInteractionType # value = <polarInteractionType.before: 1>
    error: quadoa.quadoa.polarInteractionType # value = <polarInteractionType.error: 0>
    pass
class polarReferenceCoo():
    """
    Enumeration class to specify the method for the conversion of the 3D E-field into the 2D vectro that is used in the Jones calculus.

    Members:

      error : Error value

      projection : 

      ideal : 

      axisref : 

      sp : 
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <polarReferenceCoo.error: 0>, 'projection': <polarReferenceCoo.projection: 1>, 'ideal': <polarReferenceCoo.ideal: 2>, 'axisref': <polarReferenceCoo.axisref: 3>, 'sp': <polarReferenceCoo.sp: 4>}
    axisref: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.axisref: 3>
    error: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.error: 0>
    ideal: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.ideal: 2>
    projection: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.projection: 1>
    sp: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.sp: 4>
    pass
class polarizationType():
    """
    Enumeration class to specify the type of Surface Polarization objects.

    Members:

      polarizationGeneralJones : Genral Jones matrix polarizer

      polarizationMueller : General Müller matrix polarizer

      polarizationLinearPolarizer : Linear polarizer

      polarizationCircularPolarizer : Circular polarizer

      polarizationQuarterWP : Quarter wave plate polarizer

      polarizationHalfWP : Half wave plate polarizer

      polarizationGeneralRetarder : Genral retarder polarizer

      polarizationAngleDependantRetarder : Angle dependent (interpolated) polarizer

      polarizationWaveAndAngDepRetarder : Wavelength and angle dependent (bi-linear interpolated) polarizer

      polarizationWavelengthDependantRetarder : Wavelength dependent (interpolated) polarizer

      polarizationPupilPosAndWaveDepRetarder : Pupil position and wavelength dependent (bi-linear interpolated) polarizer

      polarizationPupilPosDepRetarder : Pupil position dependent (interpolated) polarizer
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'polarizationGeneralJones': <polarizationType.polarizationGeneralJones: 0>, 'polarizationMueller': <polarizationType.polarizationMueller: 1>, 'polarizationLinearPolarizer': <polarizationType.polarizationLinearPolarizer: 2>, 'polarizationCircularPolarizer': <polarizationType.polarizationCircularPolarizer: 3>, 'polarizationQuarterWP': <polarizationType.polarizationQuarterWP: 4>, 'polarizationHalfWP': <polarizationType.polarizationHalfWP: 5>, 'polarizationGeneralRetarder': <polarizationType.polarizationGeneralRetarder: 6>, 'polarizationAngleDependantRetarder': <polarizationType.polarizationAngleDependantRetarder: 7>, 'polarizationWaveAndAngDepRetarder': <polarizationType.polarizationWaveAndAngDepRetarder: 8>, 'polarizationWavelengthDependantRetarder': <polarizationType.polarizationWavelengthDependantRetarder: 9>, 'polarizationPupilPosAndWaveDepRetarder': <polarizationType.polarizationPupilPosAndWaveDepRetarder: 10>, 'polarizationPupilPosDepRetarder': <polarizationType.polarizationPupilPosDepRetarder: 11>}
    polarizationAngleDependantRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationAngleDependantRetarder: 7>
    polarizationCircularPolarizer: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationCircularPolarizer: 3>
    polarizationGeneralJones: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationGeneralJones: 0>
    polarizationGeneralRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationGeneralRetarder: 6>
    polarizationHalfWP: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationHalfWP: 5>
    polarizationLinearPolarizer: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationLinearPolarizer: 2>
    polarizationMueller: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationMueller: 1>
    polarizationPupilPosAndWaveDepRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationPupilPosAndWaveDepRetarder: 10>
    polarizationPupilPosDepRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationPupilPosDepRetarder: 11>
    polarizationQuarterWP: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationQuarterWP: 4>
    polarizationWaveAndAngDepRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationWaveAndAngDepRetarder: 8>
    polarizationWavelengthDependantRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationWavelengthDependantRetarder: 9>
    pass
class seidelAberration():
    """
    Enumeration class for the definition of Seidel aberrations.

    Members:

      error : Error value

      sphericalW040 : Spherical Aberration

      comaW131 : Coma

      astigmatismW222 : Astigmatism

      petzvalW220 : Petzval Curvature

      distortionW311 : Distortion

      axialColor : Axial Color

      lateralColor : Laterl Color
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <seidelAberration.error: 0>, 'sphericalW040': <seidelAberration.sphericalW040: 1>, 'comaW131': <seidelAberration.comaW131: 2>, 'astigmatismW222': <seidelAberration.astigmatismW222: 3>, 'petzvalW220': <seidelAberration.petzvalW220: 4>, 'distortionW311': <seidelAberration.distortionW311: 5>, 'axialColor': <seidelAberration.axialColor: 6>, 'lateralColor': <seidelAberration.lateralColor: 7>}
    astigmatismW222: quadoa.quadoa.seidelAberration # value = <seidelAberration.astigmatismW222: 3>
    axialColor: quadoa.quadoa.seidelAberration # value = <seidelAberration.axialColor: 6>
    comaW131: quadoa.quadoa.seidelAberration # value = <seidelAberration.comaW131: 2>
    distortionW311: quadoa.quadoa.seidelAberration # value = <seidelAberration.distortionW311: 5>
    error: quadoa.quadoa.seidelAberration # value = <seidelAberration.error: 0>
    lateralColor: quadoa.quadoa.seidelAberration # value = <seidelAberration.lateralColor: 7>
    petzvalW220: quadoa.quadoa.seidelAberration # value = <seidelAberration.petzvalW220: 4>
    sphericalW040: quadoa.quadoa.seidelAberration # value = <seidelAberration.sphericalW040: 1>
    pass
class seidelType():
    """
    Enumeration class for the definition of Seidel aberrations.

    Members:

      error : Error value

      S : Seidel Aberration (S1, S2, S3, S4, S5, ...)

      W : Seidel Wavefront Error (W040, W131, W222, W220, W311, ...)
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    S: quadoa.quadoa.seidelType # value = <seidelType.S: 1>
    W: quadoa.quadoa.seidelType # value = <seidelType.W: 2>
    __members__: dict # value = {'error': <seidelType.error: 0>, 'S': <seidelType.S: 1>, 'W': <seidelType.W: 2>}
    error: quadoa.quadoa.seidelType # value = <seidelType.error: 0>
    pass
class sequenceApertureType():
    """
    Enumeration class for the definition of the aperture type of a sequence.

    Members:

      error : Error value

      objectSpaceNA : Aperture defined in object space by NA

      entrancePupil : Aperture defined in object space by Entrence Pupil Radius

      floatFromStop : Aperture is defied by stop surface aperture

      none : No Stop surface is used at all
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceApertureType.error: 0>, 'objectSpaceNA': <sequenceApertureType.objectSpaceNA: 1>, 'entrancePupil': <sequenceApertureType.entrancePupil: 2>, 'floatFromStop': <sequenceApertureType.floatFromStop: 3>, 'none': <sequenceApertureType.none: 4>}
    entrancePupil: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.entrancePupil: 2>
    error: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.error: 0>
    floatFromStop: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.floatFromStop: 3>
    none: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.none: 4>
    objectSpaceNA: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.objectSpaceNA: 1>
    pass
class sequenceApodizationType():
    """
    Enumeration class for the definition of the apodization type of a sequence.

    Members:

      error : Error value

      equal : 

      gaussian : 

      superGauss : 

      gaussianElliptic : 

      superGaussElliptic : 

      superGaussRectangular : 
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceApodizationType.error: 0>, 'equal': <sequenceApodizationType.equal: 1>, 'gaussian': <sequenceApodizationType.gaussian: 2>, 'superGauss': <sequenceApodizationType.superGauss: 3>, 'gaussianElliptic': <sequenceApodizationType.gaussianElliptic: 4>, 'superGaussElliptic': <sequenceApodizationType.superGaussElliptic: 5>, 'superGaussRectangular': <sequenceApodizationType.superGaussRectangular: 6>}
    equal: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.equal: 1>
    error: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.error: 0>
    gaussian: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.gaussian: 2>
    gaussianElliptic: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.gaussianElliptic: 4>
    superGauss: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.superGauss: 3>
    superGaussElliptic: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.superGaussElliptic: 5>
    superGaussRectangular: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.superGaussRectangular: 6>
    pass
class sequenceDistributionType():
    """
    Enumeration class for the definition of the aperture type of a sequence.

    Members:

      error : Error value

      singleFreeDefRay : Single Ray defined by normed aperture position

      fanY : Fan of rays along Y-axis

      fanX : Fan of rays along X-axis

      fanXY : Fan of rays along X- and Y-axis

      singleRing : A ring of rays at the edge of the aperture

      equalDensityRings : Concentric rings where the amount of rays is proportional to the radius of each ring

      hubLike : Concentric rings of rays with equal amount of rays in each ring

      gridHexagonal : Hexagonal 2D grid of rays

      gridQuadratic : Quadratic 2D grid of rays

      gridOptimized : Grid optimized for wavefront error optimization

      randomEqualDensity : Random ray distribution

      quasiRandom : Quasi random ray distribution
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceDistributionType.error: 0>, 'singleFreeDefRay': <sequenceDistributionType.singleFreeDefRay: 1>, 'fanY': <sequenceDistributionType.fanY: 2>, 'fanX': <sequenceDistributionType.fanX: 3>, 'fanXY': <sequenceDistributionType.fanX: 3>, 'singleRing': <sequenceDistributionType.singleRing: 5>, 'equalDensityRings': <sequenceDistributionType.equalDensityRings: 6>, 'hubLike': <sequenceDistributionType.hubLike: 7>, 'gridHexagonal': <sequenceDistributionType.gridHexagonal: 8>, 'gridQuadratic': <sequenceDistributionType.gridQuadratic: 9>, 'gridOptimized': <sequenceDistributionType.gridOptimized: 10>, 'randomEqualDensity': <sequenceDistributionType.randomEqualDensity: 11>, 'quasiRandom': <sequenceDistributionType.quasiRandom: 12>}
    equalDensityRings: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.equalDensityRings: 6>
    error: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.error: 0>
    fanX: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.fanX: 3>
    fanXY: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.fanX: 3>
    fanY: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.fanY: 2>
    gridHexagonal: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.gridHexagonal: 8>
    gridOptimized: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.gridOptimized: 10>
    gridQuadratic: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.gridQuadratic: 9>
    hubLike: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.hubLike: 7>
    quasiRandom: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.quasiRandom: 12>
    randomEqualDensity: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.randomEqualDensity: 11>
    singleFreeDefRay: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.singleFreeDefRay: 1>
    singleRing: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.singleRing: 5>
    pass
class sequenceFieldType():
    """
    Enumeration class for the definition of the field type of a sequence.

    Members:

      error : Error value

      objectHeight : Field defined by object space height

      fieldAngle : Field defined by chief ray angle

      imageHeight : Field defined by image space height

      positionAndAngle : Only for sequence with aperture type none

      noField : Only for wavefront from surfaces sources
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceFieldType.error: 0>, 'objectHeight': <sequenceFieldType.objectHeight: 1>, 'fieldAngle': <sequenceFieldType.fieldAngle: 2>, 'imageHeight': <sequenceFieldType.imageHeight: 3>, 'positionAndAngle': <sequenceFieldType.positionAndAngle: 4>, 'noField': <sequenceFieldType.noField: 5>}
    error: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.error: 0>
    fieldAngle: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.fieldAngle: 2>
    imageHeight: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.imageHeight: 3>
    noField: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.noField: 5>
    objectHeight: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.objectHeight: 1>
    positionAndAngle: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.positionAndAngle: 4>
    pass
class sequenceImageSpaceType():
    """
    Enumeration class for the definition of the image space.

    Members:

      error : Error value

      focal : The system is focal and spot diragrams and other plots in image space are calcualted in length units

      afocal : The system is afocal and spot diagrams and other plots are computed in angular units
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceImageSpaceType.error: 0>, 'focal': <sequenceImageSpaceType.focal: 1>, 'afocal': <sequenceImageSpaceType.afocal: 2>}
    afocal: quadoa.quadoa.sequenceImageSpaceType # value = <sequenceImageSpaceType.afocal: 2>
    error: quadoa.quadoa.sequenceImageSpaceType # value = <sequenceImageSpaceType.error: 0>
    focal: quadoa.quadoa.sequenceImageSpaceType # value = <sequenceImageSpaceType.focal: 1>
    pass
class sequenceOPDChiefRefType():
    """
    Enumeration class for the definition of the Wavlenght dependandt OPD reference type of a sequence.

    Members:

      error : Error value

      ownChief : The tilt-free reference is assumed to be the chiefray of each individual wavelength. (Lareral chromatic aberration is ignored)

      primaryChief : The tilt-free reference is assumed to be the primary chiefray. (Lareral chromatic aberration results in tilt)
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceOPDChiefRefType.error: 0>, 'ownChief': <sequenceOPDChiefRefType.ownChief: 1>, 'primaryChief': <sequenceOPDChiefRefType.primaryChief: 2>}
    error: quadoa.quadoa.sequenceOPDChiefRefType # value = <sequenceOPDChiefRefType.error: 0>
    ownChief: quadoa.quadoa.sequenceOPDChiefRefType # value = <sequenceOPDChiefRefType.ownChief: 1>
    primaryChief: quadoa.quadoa.sequenceOPDChiefRefType # value = <sequenceOPDChiefRefType.primaryChief: 2>
    pass
class sequenceOPDRefType():
    """
    Enumeration class for the definition of the OPD calcualtion mode type of a sequence.

    Members:

      error : Error value

      exitPupil : The OPL is calcualted in the exit pupil and is corrected for spherical wave. This is the preferred mode for focal systems.

      afocalExitPupil : The OPL is calcualted in the exit pupil and is corrected for tilt of the chief ray wave. This is the preferred mode for afocal systems.

      absOverImageSurf : The OPL is the total OPL through the system and the x,y-coordinates are on the image surface

      absOverExitPupil : The OPL is the total OPL through the system but the x,y-coordinates are in the exit pupil.
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceOPDRefType.error: 0>, 'exitPupil': <sequenceOPDRefType.exitPupil: 1>, 'afocalExitPupil': <sequenceOPDRefType.afocalExitPupil: 2>, 'absOverImageSurf': <sequenceOPDRefType.absOverImageSurf: 3>, 'absOverExitPupil': <sequenceOPDRefType.absOverExitPupil: 4>}
    absOverExitPupil: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.absOverExitPupil: 4>
    absOverImageSurf: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.absOverImageSurf: 3>
    afocalExitPupil: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.afocalExitPupil: 2>
    error: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.error: 0>
    exitPupil: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.exitPupil: 1>
    pass
class sequencePolarizationType():
    """
    Enumeration class for the definition of the polarization type of a sequence.

    Members:

      error : Error value

      none : Polarization is not computed

      linear : Linear Jones Vector Polarization

      circular : Circular Jones Vector Polarization

      jonesComplex : Jones Vector

      jonesPhase : Jones Vector

      stokes : Stokes Vector

      random : Random Jones Vector
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequencePolarizationType.error: 0>, 'none': <sequencePolarizationType.none: 1>, 'linear': <sequencePolarizationType.linear: 2>, 'circular': <sequencePolarizationType.circular: 3>, 'jonesComplex': <sequencePolarizationType.jonesComplex: 4>, 'jonesPhase': <sequencePolarizationType.jonesPhase: 5>, 'stokes': <sequencePolarizationType.jonesComplex: 4>, 'random': <sequencePolarizationType.jonesPhase: 5>}
    circular: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.circular: 3>
    error: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.error: 0>
    jonesComplex: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesComplex: 4>
    jonesPhase: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesPhase: 5>
    linear: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.linear: 2>
    none: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.none: 1>
    random: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesPhase: 5>
    stokes: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesComplex: 4>
    pass
class sequenceSourceType():
    """
    Enumeration class for the definition of the ray start conditions of a sequence.

    Members:

      error : Error value

      pointSource : Rays start from a point source

      planeWF : Rays start as parralel rays (collimated)

      fromSurface : Rays start orthogonal to the first surface

      extendedSource : Rays start at random position and angle according to the extended source settings

      rayfile : Rays are taken from rayfile

      gaussianBeam : Rays arranged for methods that are suitable for calculating Gaussian beam paramters
    """
    def __eq__(self, other: object) -> bool: ...
    def __getstate__(self) -> int: ...
    def __hash__(self) -> int: ...
    def __init__(self, value: int) -> None: ...
    def __int__(self) -> int: ...
    def __ne__(self, other: object) -> bool: ...
    def __repr__(self) -> str: ...
    def __setstate__(self, state: int) -> None: ...
    @property
    def name(self) -> str:
        """
        :type: str
        """
    @property
    def value(self) -> int:
        """
        :type: int
        """
    __members__: dict # value = {'error': <sequenceSourceType.error: 0>, 'pointSource': <sequenceSourceType.pointSource: 1>, 'planeWF': <sequenceSourceType.planeWF: 2>, 'fromSurface': <sequenceSourceType.fromSurface: 3>, 'extendedSource': <sequenceSourceType.extendedSource: 4>, 'rayfile': <sequenceSourceType.rayfile: 5>, 'gaussianBeam': <sequenceSourceType.gaussianBeam: 6>}
    error: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.error: 0>
    extendedSource: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.extendedSource: 4>
    fromSurface: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.fromSurface: 3>
    gaussianBeam: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.gaussianBeam: 6>
    planeWF: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.planeWF: 2>
    pointSource: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.pointSource: 1>
    rayfile: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.rayfile: 5>
    pass
IGES: quadoa.quadoa.cadFileType # value = <cadFileType.STEP: 1>
S: quadoa.quadoa.seidelType # value = <seidelType.S: 1>
STEP: quadoa.quadoa.importMode # value = <importMode.STEP: 2>
STL: quadoa.quadoa.importMode # value = <importMode.STL: 0>
W: quadoa.quadoa.seidelType # value = <seidelType.W: 2>
__version__ = '25.4.0'
absOverExitPupil: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.absOverExitPupil: 4>
absOverImageSurf: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.absOverImageSurf: 3>
afocal: quadoa.quadoa.sequenceImageSpaceType # value = <sequenceImageSpaceType.afocal: 2>
afocalExitPupil: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.afocalExitPupil: 2>
after: quadoa.quadoa.polarInteractionType # value = <polarInteractionType.after: 2>
allFieldAllWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.allFieldAllWave: 4>
allFieldPrimaryWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.allFieldPrimaryWave: 3>
apertureAnnular: quadoa.quadoa.apertureType # value = <apertureType.apertureAnnular: 5>
apertureArray: quadoa.quadoa.apertureType # value = <apertureType.apertureArray: 6>
apertureCirc: quadoa.quadoa.apertureType # value = <apertureType.apertureCirc: 0>
apertureElliptic: quadoa.quadoa.apertureType # value = <apertureType.apertureElliptic: 4>
apertureHex: quadoa.quadoa.apertureType # value = <apertureType.apertureHex: 2>
apertureOr: quadoa.quadoa.apertureType # value = <apertureType.apertureOr: 7>
aperturePolygon: quadoa.quadoa.apertureType # value = <apertureType.aperturePolygon: 3>
apertureRect: quadoa.quadoa.apertureType # value = <apertureType.apertureRect: 1>
astigmatismW222: quadoa.quadoa.seidelAberration # value = <seidelAberration.astigmatismW222: 3>
attenuatorConst: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleDependant: 4>
attenuatorCosine: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleAndWaveDependant: 5>
attenuatorGauss: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleAndWaveDependant: 5>
axialColor: quadoa.quadoa.seidelAberration # value = <seidelAberration.axialColor: 6>
axisref: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.axisref: 3>
before: quadoa.quadoa.polarInteractionType # value = <polarInteractionType.before: 1>
circular: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.circular: 3>
coatingAngleAndWaveDependant: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleAndWaveDependant: 5>
coatingAngleDependant: quadoa.quadoa.coatingType # value = <coatingType.coatingAngleDependant: 4>
coatingArray: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealMirror: 2>
coatingFullData: quadoa.quadoa.coatingType # value = <coatingType.coatingFullData: 6>
coatingIdealAR: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealAR: 1>
coatingIdealMirror: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealMirror: 2>
coatingPupilPosDependant: quadoa.quadoa.coatingType # value = <coatingType.coatingSimple: 0>
coatingSimple: quadoa.quadoa.coatingType # value = <coatingType.coatingSimple: 0>
coatingThinFilmStack: quadoa.quadoa.coatingType # value = <coatingType.coatingIdealAR: 1>
coatingWavelengthDep: quadoa.quadoa.coatingType # value = <coatingType.coatingWavelengthDep: 3>
comaW131: quadoa.quadoa.seidelAberration # value = <seidelAberration.comaW131: 2>
distortionW311: quadoa.quadoa.seidelAberration # value = <seidelAberration.distortionW311: 5>
entrancePupil: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.entrancePupil: 2>
equal: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.equal: 1>
equalDensityRings: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.equalDensityRings: 6>
error: quadoa.quadoa.seidelAberration # value = <seidelAberration.error: 0>
exitPupil: quadoa.quadoa.sequenceOPDRefType # value = <sequenceOPDRefType.exitPupil: 1>
extendedSource: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.extendedSource: 4>
fanX: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.fanX: 3>
fanXY: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.fanX: 3>
fanY: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.fanY: 2>
fieldAngle: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.fieldAngle: 2>
firstFieldAllWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.firstFieldAllWave: 2>
firstFieldPrimaryWave: quadoa.quadoa.ghostGenFieldWaveType # value = <ghostGenFieldWaveType.firstFieldPrimaryWave: 1>
floatFromStop: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.floatFromStop: 3>
focal: quadoa.quadoa.sequenceImageSpaceType # value = <sequenceImageSpaceType.focal: 1>
formAcylinder: quadoa.quadoa.formType # value = <formType.formAcylinder: 14>
formAcylinderQBfs: quadoa.quadoa.formType # value = <formType.formAcylinder: 14>
formAcylinderQCon: quadoa.quadoa.formType # value = <formType.formAcylinder: 14>
formAsphere: quadoa.quadoa.formType # value = <formType.formAsphere: 11>
formAsphereQBfs: quadoa.quadoa.formType # value = <formType.formAsphereQBfs: 13>
formAsphereQCon: quadoa.quadoa.formType # value = <formType.formAsphereQCon: 12>
formAxicon: quadoa.quadoa.formType # value = <formType.formAxicon: 19>
formBiconic: quadoa.quadoa.formType # value = <formType.formBiconic: 21>
formCosine: quadoa.quadoa.formType # value = <formType.formCosine: 22>
formCylinder: quadoa.quadoa.formType # value = <formType.formCylinder: 17>
formGaussPeak: quadoa.quadoa.formType # value = <formType.formGaussPeak: 24>
formGaussPeakElliptic: quadoa.quadoa.formType # value = <formType.formGaussPeakElliptic: 26>
formGaussPeakEllipticSuper: quadoa.quadoa.formType # value = <formType.formGaussPeakEllipticSuper: 27>
formGaussPeakRectangularSuper: quadoa.quadoa.formType # value = <formType.formGaussPeakRectangularSuper: 28>
formGaussPeakSuper: quadoa.quadoa.formType # value = <formType.formGaussPeakSuper: 25>
formInterp: quadoa.quadoa.formType # value = <formType.formInterp: 29>
formManipulationOperator: quadoa.quadoa.formType # value = <formType.formManipulationOperator: 34>
formOffAxisAsphere: quadoa.quadoa.formType # value = <formType.formOffAxisAsphere: 20>
formOperatorArray: quadoa.quadoa.formType # value = <formType.formOperatorArray: 31>
formOperatorFresnel: quadoa.quadoa.formType # value = <formType.formOperatorFresnel: 33>
formOperatorHexArray: quadoa.quadoa.formType # value = <formType.formOperatorHexArray: 32>
formParaboloid: quadoa.quadoa.formType # value = <formType.formParaboloid: 8>
formPeriodicRotation: quadoa.quadoa.formType # value = <formType.formPeriodicRotation: 23>
formPlane: quadoa.quadoa.formType # value = <formType.formPlane: 0>
formPython: quadoa.quadoa.formType # value = <formType.formPython: 30>
formSphere: quadoa.quadoa.formType # value = <formType.formSphere: 1>
formTorus: quadoa.quadoa.formType # value = <formType.formTorus: 18>
formXYZPoly: quadoa.quadoa.formType # value = <formType.formXYZPoly: 4>
formZernFringe: quadoa.quadoa.formType # value = <formType.formZernFringe: 3>
formZernSymmetric: quadoa.quadoa.formType # value = <formType.formZernSymmetric: 2>
fromSurface: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.fromSurface: 3>
gaussian: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.gaussian: 2>
gaussianBeam: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.gaussianBeam: 6>
gaussianElliptic: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.gaussianElliptic: 4>
gridHexagonal: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.gridHexagonal: 8>
gridOptimized: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.gridOptimized: 10>
gridQuadratic: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.gridQuadratic: 9>
hubLike: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.hubLike: 7>
ideal: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.ideal: 2>
imageHeight: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.imageHeight: 3>
jonesComplex: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesComplex: 4>
jonesPhase: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesPhase: 5>
keepAll: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.keepAll: 3>
lateralColor: quadoa.quadoa.seidelAberration # value = <seidelAberration.lateralColor: 7>
linear: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.linear: 2>
minimal: quadoa.quadoa.ghostGenRayType # value = <ghostGenRayType.minimal: 1>
noField: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.noField: 5>
none: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.none: 1>
objectHeight: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.objectHeight: 1>
objectSpaceNA: quadoa.quadoa.sequenceApertureType # value = <sequenceApertureType.objectSpaceNA: 1>
obscurationCirc: quadoa.quadoa.obscurationType # value = <obscurationType.obscurationCirc: 0>
obscurationElliptic: quadoa.quadoa.obscurationType # value = <obscurationType.obscurationElliptic: 2>
obscurationRect: quadoa.quadoa.obscurationType # value = <obscurationType.obscurationRect: 1>
onPlane: quadoa.quadoa.distributionFootprintType # value = <distributionFootprintType.onPlane: 1>
onSphere: quadoa.quadoa.distributionFootprintType # value = <distributionFootprintType.onSphere: 2>
ownChief: quadoa.quadoa.sequenceOPDChiefRefType # value = <sequenceOPDChiefRefType.ownChief: 1>
paramBool: quadoa.quadoa.paramType # value = <paramType.paramBool: 5>
paramDouble: quadoa.quadoa.paramType # value = <paramType.paramDouble: 4>
paramDummy: quadoa.quadoa.paramType # value = <paramType.paramDummy: 1>
paramError: quadoa.quadoa.paramType # value = <paramType.paramError: 0>
paramInt: quadoa.quadoa.paramType # value = <paramType.paramInt: 2>
paramString: quadoa.quadoa.paramType # value = <paramType.paramString: 3>
petzvalW220: quadoa.quadoa.seidelAberration # value = <seidelAberration.petzvalW220: 4>
phaseAxial: quadoa.quadoa.phaseType # value = <phaseType.phaseAxial: 5>
phaseGaussPeak: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeak: 7>
phaseGaussPeakElliptic: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakElliptic: 9>
phaseGaussPeakEllipticSuper: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakEllipticSuper: 10>
phaseGaussPeakRectangularSuper: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakRectangularSuper: 11>
phaseGaussPeakSuper: quadoa.quadoa.phaseType # value = <phaseType.phaseGaussPeakSuper: 8>
phaseGrating: quadoa.quadoa.phaseType # value = <phaseType.phaseGrating: 3>
phaseInterp: quadoa.quadoa.phaseType # value = <phaseType.phaseInterp: 12>
phaseManipulationOperator: quadoa.quadoa.phaseType # value = <phaseType.phaseManipulationOperator: 16>
phaseOperatorArray: quadoa.quadoa.phaseType # value = <phaseType.phaseOperatorArray: 14>
phaseOperatorHexArray: quadoa.quadoa.phaseType # value = <phaseType.phaseOperatorHexArray: 15>
phasePython: quadoa.quadoa.phaseType # value = <phaseType.phasePython: 13>
phaseRadial: quadoa.quadoa.phaseType # value = <phaseType.phaseRadial: 4>
phaseSpiral: quadoa.quadoa.phaseType # value = <phaseType.phaseSpiral: 6>
phaseXYZPoly: quadoa.quadoa.phaseType # value = <phaseType.phaseXYZPoly: 2>
phaseZernFringe: quadoa.quadoa.phaseType # value = <phaseType.phaseZernFringe: 1>
phaseZernSymmetric: quadoa.quadoa.phaseType # value = <phaseType.phaseZernSymmetric: 0>
planeWF: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.planeWF: 2>
pointSource: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.pointSource: 1>
polarizationAngleDependantRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationAngleDependantRetarder: 7>
polarizationCircularPolarizer: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationCircularPolarizer: 3>
polarizationGeneralJones: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationGeneralJones: 0>
polarizationGeneralRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationGeneralRetarder: 6>
polarizationHalfWP: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationHalfWP: 5>
polarizationLinearPolarizer: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationLinearPolarizer: 2>
polarizationMueller: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationMueller: 1>
polarizationPupilPosAndWaveDepRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationPupilPosAndWaveDepRetarder: 10>
polarizationPupilPosDepRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationPupilPosDepRetarder: 11>
polarizationQuarterWP: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationQuarterWP: 4>
polarizationWaveAndAngDepRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationWaveAndAngDepRetarder: 8>
polarizationWavelengthDependantRetarder: quadoa.quadoa.polarizationType # value = <polarizationType.polarizationWavelengthDependantRetarder: 9>
positionAndAngle: quadoa.quadoa.sequenceFieldType # value = <sequenceFieldType.positionAndAngle: 4>
primaryChief: quadoa.quadoa.sequenceOPDChiefRefType # value = <sequenceOPDChiefRefType.primaryChief: 2>
projection: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.projection: 1>
quasiRandom: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.quasiRandom: 12>
random: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesPhase: 5>
randomEqualDensity: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.randomEqualDensity: 11>
rayfile: quadoa.quadoa.sequenceSourceType # value = <sequenceSourceType.rayfile: 5>
sameAsSequence: quadoa.quadoa.ghostGenRayType # value = <ghostGenRayType.sameAsSequence: 2>
singleFreeDefRay: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.singleFreeDefRay: 1>
singleRing: quadoa.quadoa.sequenceDistributionType # value = <sequenceDistributionType.singleRing: 5>
sp: quadoa.quadoa.polarReferenceCoo # value = <polarReferenceCoo.sp: 4>
sphericalW040: quadoa.quadoa.seidelAberration # value = <seidelAberration.sphericalW040: 1>
stokes: quadoa.quadoa.sequencePolarizationType # value = <sequencePolarizationType.jonesComplex: 4>
superGauss: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.superGauss: 3>
superGaussElliptic: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.superGaussElliptic: 5>
superGaussRectangular: quadoa.quadoa.sequenceApodizationType # value = <sequenceApodizationType.superGaussRectangular: 6>
worstByMaxIrrad: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.worstByMaxIrrad: 1>
worstByTotalFlux: quadoa.quadoa.ghostKeepType # value = <ghostKeepType.worstByTotalFlux: 2>
